/**
 * UI Module - 界面和工具函数
 * 包含：工具函数、UI导航、仪表盘
 */

// ============================================
// Utility Functions
// ============================================
function showMessage(message, type = 'info') {
    const messageArea = document.getElementById('messageArea');
    if (!messageArea) return;
    
    const alertClass = type === 'success' ? 'alert-success' : 
                      type === 'error' ? 'alert-error' : 'alert-info';
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert ${alertClass}`;
    alertDiv.textContent = message;
    alertDiv.style.marginBottom = '8px';
    
    messageArea.appendChild(alertDiv);
    setTimeout(() => alertDiv.remove(), 5000);
}

function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function formatNumber(num) {
    if (num === null || num === undefined) return '0';
    return num.toLocaleString();
}

function formatDuration(ms) {
    if (!ms || ms <= 0) return '';
    const totalSeconds = Math.floor(ms / 1000);
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    
    if (h > 0) {
        return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m}:${s.toString().padStart(2, '0')}`;
}

function formatRelativeTime(dateStr) {
    if (!dateStr) return '';
    
    try {
        const date = new Date(dateStr);
        const now = new Date();
        const diffMs = now - date;
        const diffSec = Math.floor(diffMs / 1000);
        const diffMin = Math.floor(diffSec / 60);
        const diffHour = Math.floor(diffMin / 60);
        const diffDay = Math.floor(diffHour / 24);
        
        if (diffSec < 60) return '刚刚';
        if (diffMin < 60) return `${diffMin}分钟前`;
        if (diffHour < 24) return `${diffHour}小时前`;
        if (diffDay === 1) return '昨天';
        if (diffDay < 7) return `${diffDay}天前`;
        
        return `${date.getMonth() + 1}月${date.getDate()}日`;
    } catch (e) {
        return dateStr;
    }
}

function formatChartLabel(dateStr) {
    try {
        const date = new Date(dateStr);
        return `${date.getMonth() + 1}/${date.getDate()}`;
    } catch (e) {
        return dateStr;
    }
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function getStatusText(status) {
    const statusMap = {
        'completed': '已完成',
        'failed': '失败',
        'in_progress': '下载中',
        'pending': '等待中',
        'paused': '已暂停'
    };
    return statusMap[status] || status || '未知';
}

// ============================================
// UI Navigation
// ============================================
let currentPage = 'dashboard';
const validPages = ['dashboard', 'browse', 'downloads', 'batch', 'queue', 'settings'];
const pageTitles = {
    dashboard: '仪表盘',
    browse: '浏览记录',
    downloads: '下载记录',
    batch: '批量下载',
    queue: '下载队列',
    settings: '设置'
};

function navigateTo(page, updateHistory = true) {
    if (!validPages.includes(page)) {
        console.warn(`Invalid page: ${page}, defaulting to dashboard`);
        page = 'dashboard';
    }
    
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === page) {
            item.classList.add('active');
        }
    });

    document.querySelectorAll('.page-view').forEach(view => {
        view.classList.remove('active');
    });
    const pageElement = document.getElementById(`page-${page}`);
    if (pageElement) {
        pageElement.classList.add('active');
    }

    const titleEl = document.getElementById('pageTitle');
    if (titleEl) {
        titleEl.textContent = pageTitles[page] || page;
    }

    currentPage = page;
    
    if (updateHistory && window.location.hash !== `#${page}`) {
        history.pushState({ page }, pageTitles[page], `#${page}`);
    }

    if (window.innerWidth <= 768) {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('sidebarOverlay');
        if (sidebar) sidebar.classList.remove('open');
        if (overlay) overlay.classList.remove('open');
    }

    loadPageData(page);
}

function handlePopState(event) {
    const page = event.state?.page || getPageFromHash() || 'dashboard';
    navigateTo(page, false);
}

function getPageFromHash() {
    const hash = window.location.hash.slice(1);
    return validPages.includes(hash) ? hash : null;
}

function initRouter() {
    window.addEventListener('popstate', handlePopState);
    const initialPage = getPageFromHash() || 'dashboard';
    if (initialPage !== 'dashboard') {
        navigateTo(initialPage, false);
    }
    history.replaceState({ page: initialPage }, pageTitles[initialPage], `#${initialPage}`);
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    if (sidebar) sidebar.classList.toggle('open');
    if (overlay) overlay.classList.toggle('open');
}

// ============================================
// Page Data Loading
// ============================================
async function loadPageData(page) {
    if (ConnectionManager.getStatus() !== 'connected') return;

    try {
        switch (page) {
            case 'dashboard': await loadDashboardData(); break;
            case 'browse': await loadBrowseHistory(); break;
            case 'downloads': await loadDownloadRecords(); break;
            case 'queue': await loadDownloadQueue(); break;
            case 'settings': await loadSettings(); break;
        }
    } catch (e) {
        console.error('Failed to load page data:', e);
    }
}

async function loadDashboardData() {
    try {
        const stats = await ApiClient.getStatistics();
        if (stats.success && stats.data) {
            const data = stats.data;
            const el = (id) => document.getElementById(id);
            if (el('statTotalBrowse')) el('statTotalBrowse').textContent = formatNumber(data.totalBrowseCount || 0);
            if (el('statTotalDownload')) el('statTotalDownload').textContent = formatNumber(data.totalDownloadCount || 0);
            if (el('statTodayDownload')) el('statTodayDownload').textContent = formatNumber(data.todayDownloadCount || 0);
            if (el('statStorage')) el('statStorage').textContent = formatBytes(data.storageUsed || 0);
            
            renderRecentBrowseList(data.recentBrowse || []);
            renderRecentDownloadList(data.recentDownload || []);
        }
        await loadChartData();
    } catch (e) {
        console.error('Failed to load dashboard data:', e);
    }
}

async function loadChartData() {
    try {
        const chartData = await ApiClient.getChartData();
        if (chartData.success && chartData.data) {
            renderChart(chartData.data);
        } else {
            renderEmptyChart();
        }
    } catch (e) {
        console.error('Failed to load chart data:', e);
        renderEmptyChart();
    }
}

function renderChart(data) {
    const container = document.getElementById('chartBars');
    if (!container) return;
    
    if (!data.labels || !data.values || data.labels.length === 0) {
        renderEmptyChart();
        return;
    }
    
    const maxValue = Math.max(...data.values, 1);
    const maxHeight = 140;
    
    let html = '';
    for (let i = 0; i < data.labels.length; i++) {
        const value = data.values[i] || 0;
        const height = Math.max((value / maxValue) * maxHeight, 4);
        const label = formatChartLabel(data.labels[i]);
        
        html += `
            <div class="chart-bar-wrapper">
                <div class="chart-bar" style="height: ${height}px;" title="${data.labels[i]}: ${value} 次下载">
                    ${value > 0 ? `<span class="chart-bar-value">${value}</span>` : ''}
                </div>
                <span class="chart-label">${label}</span>
            </div>
        `;
    }
    
    container.innerHTML = html;
}

function renderEmptyChart() {
    const container = document.getElementById('chartBars');
    if (container) {
        container.innerHTML = '<div class="chart-empty">暂无下载数据</div>';
    }
}

function renderRecentBrowseList(records) {
    const container = document.getElementById('recentBrowseList');
    if (!container) return;
    
    if (!records || records.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                    <circle cx="12" cy="12" r="3"/>
                </svg>
                <p>暂无浏览记录</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    for (const record of records) {
        const thumbnail = record.coverUrl 
            ? `<img class="recent-thumbnail" src="${escapeHtml(record.coverUrl)}" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"><div class="recent-thumbnail-placeholder" style="display:none"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg></div>`
            : `<div class="recent-thumbnail-placeholder"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg></div>`;
        
        html += `
            <div class="recent-item" onclick="viewBrowseRecord('${escapeHtml(record.id)}')">
                ${thumbnail}
                <div class="recent-info">
                    <div class="recent-title">${escapeHtml(record.title || '无标题')}</div>
                    <div class="recent-meta">
                        <span>${escapeHtml(record.author || '未知作者')}</span>
                        ${record.duration ? `<span>${formatDuration(record.duration)}</span>` : ''}
                        ${record.browseTime ? `<span>${formatRelativeTime(record.browseTime)}</span>` : ''}
                    </div>
                </div>
            </div>
        `;
    }
    
    container.innerHTML = html;
}

function renderRecentDownloadList(records) {
    const container = document.getElementById('recentDownloadList');
    if (!container) return;
    
    if (!records || records.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
                </svg>
                <p>暂无下载记录</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    for (const record of records) {
        html += `
            <div class="recent-item" onclick="viewDownloadRecord('${escapeHtml(record.id)}')">
                <div class="recent-thumbnail-placeholder">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                        <polyline points="14 2 14 8 20 8"/>
                    </svg>
                </div>
                <div class="recent-info">
                    <div class="recent-title">${escapeHtml(record.title || '无标题')}</div>
                    <div class="recent-meta">
                        <span>${escapeHtml(record.author || '未知作者')}</span>
                        ${record.fileSize ? `<span>${formatBytes(record.fileSize)}</span>` : ''}
                        ${record.downloadTime ? `<span>${formatRelativeTime(record.downloadTime)}</span>` : ''}
                    </div>
                </div>
                <span class="recent-status ${record.status || 'completed'}">${getStatusText(record.status)}</span>
            </div>
        `;
    }
    
    container.innerHTML = html;
}

function viewBrowseRecord(id) {
    navigateTo('browse');
}

function viewDownloadRecord(id) {
    navigateTo('downloads');
}

console.log('UI module loaded');
