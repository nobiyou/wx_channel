/**
 * 主应用入口
 * 负责初始化和页面路由
 */

// 应用状态
const AppState = {
    currentPage: 'dashboard',
    initialized: false
};

// ==================== 页面路由 ====================

/**
 * 切换页面
 */
function switchPage(pageName) {
    // 更新导航状态
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
        if (item.dataset.page === pageName) {
            item.classList.add('active');
        }
    });
    
    // 隐藏所有页面
    document.querySelectorAll('.page-content').forEach(page => {
        page.style.display = 'none';
    });
    
    // 显示目标页面
    const targetPage = document.getElementById(`${pageName}-page`);
    if (targetPage) {
        targetPage.style.display = 'block';
        AppState.currentPage = pageName;
        
        // 触发页面加载事件
        loadPageData(pageName);
        
        // 更新 URL
        setUrlParam('page', pageName);
    }
}

/**
 * 加载页面数据
 */
function loadPageData(pageName) {
    switch (pageName) {
        case 'dashboard':
            if (typeof loadDashboardData === 'function') {
                loadDashboardData();
            }
            break;
        case 'browse':
            if (typeof loadBrowseRecords === 'function') {
                loadBrowseRecords();
            }
            break;
        case 'downloads':
            if (typeof loadDownloadRecords === 'function') {
                loadDownloadRecords();
            }
            break;
        case 'queue':
            if (typeof loadDownloadQueue === 'function') {
                loadDownloadQueue();
            }
            break;
        case 'batch':
            // 批量下载页面不需要自动加载数据
            break;
        case 'settings':
            if (typeof loadSettings === 'function') {
                loadSettings();
            }
            break;
    }
}

// ==================== 初始化 ====================

/**
 * 初始化应用
 */
function initApp() {
    if (AppState.initialized) return;
    
    console.log('初始化应用...');
    
    // 绑定导航点击事件
    document.querySelectorAll('.nav-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const pageName = item.dataset.page;
            if (pageName) {
                switchPage(pageName);
            }
        });
    });
    
    // 从 URL 获取初始页面
    const initialPage = getUrlParam('page') || 'dashboard';
    switchPage(initialPage);
    
    // 初始化 WebSocket（如果需要）
    initWebSocket();
    
    AppState.initialized = true;
    console.log('应用初始化完成');
}

// ==================== WebSocket ====================

let ws = null;
let wsReconnectTimer = null;

/**
 * 初始化 WebSocket 连接
 */
function initWebSocket() {
    // 如果不需要实时更新，可以跳过
    if (!window.location.protocol.startsWith('http')) {
        return;
    }
    
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    try {
        ws = new WebSocket(wsUrl);
        
        ws.onopen = () => {
            console.log('WebSocket 连接已建立');
            if (wsReconnectTimer) {
                clearTimeout(wsReconnectTimer);
                wsReconnectTimer = null;
            }
        };
        
        ws.onmessage = (event) => {
            try {
                const data = JSON.parse(event.data);
                handleWebSocketMessage(data);
            } catch (e) {
                console.error('解析 WebSocket 消息失败:', e);
            }
        };
        
        ws.onerror = (error) => {
            console.error('WebSocket 错误:', error);
        };
        
        ws.onclose = () => {
            console.log('WebSocket 连接已关闭');
            // 5秒后尝试重连
            wsReconnectTimer = setTimeout(() => {
                console.log('尝试重新连接 WebSocket...');
                initWebSocket();
            }, 5000);
        };
    } catch (e) {
        console.error('创建 WebSocket 连接失败:', e);
    }
}

/**
 * 处理 WebSocket 消息
 */
function handleWebSocketMessage(data) {
    switch (data.type) {
        case 'queue_update':
            // 更新队列进度
            if (typeof updateQueueItemProgress === 'function') {
                updateQueueItemProgress(data.item);
            }
            break;
        case 'download_complete':
            // 下载完成通知
            showMessage(`视频下载完成: ${data.title}`, 'success');
            if (AppState.currentPage === 'queue') {
                loadDownloadQueue();
            }
            break;
        case 'download_error':
            // 下载错误通知
            showMessage(`下载失败: ${data.error}`, 'error');
            break;
        default:
            console.log('未知的 WebSocket 消息类型:', data.type);
    }
}

// ==================== 页面加载完成后初始化 ====================

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
} else {
    initApp();
}

// ==================== 全局错误处理 ====================

window.addEventListener('error', (event) => {
    console.error('全局错误:', event.error);
});

window.addEventListener('unhandledrejection', (event) => {
    console.error('未处理的 Promise 拒绝:', event.reason);
});

// ==================== 导出 ====================

if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        switchPage,
        loadPageData,
        initApp
    };
}
