/**
 * API 客户端模块
 * 封装所有后端 API 调用
 */

const ApiClient = {
    // 基础 URL（可配置）
    baseUrl: '',
    
    // ==================== 通用请求方法 ====================
    
    /**
     * 发送 GET 请求
     */
    async get(endpoint) {
        try {
            const response = await fetch(this.baseUrl + endpoint);
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            return await response.json();
        } catch (error) {
            console.error(`GET ${endpoint} 失败:`, error);
            throw error;
        }
    },
    
    /**
     * 发送 POST 请求
     */
    async post(endpoint, data) {
        try {
            const response = await fetch(this.baseUrl + endpoint, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            return await response.json();
        } catch (error) {
            console.error(`POST ${endpoint} 失败:`, error);
            throw error;
        }
    },
    
    /**
     * 发送 DELETE 请求
     */
    async delete(endpoint) {
        try {
            const response = await fetch(this.baseUrl + endpoint, {
                method: 'DELETE'
            });
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            return await response.json();
        } catch (error) {
            console.error(`DELETE ${endpoint} 失败:`, error);
            throw error;
        }
    },
    
    // ==================== 仪表盘 API ====================
    
    /**
     * 获取仪表盘统计数据
     */
    async getDashboardStats() {
        return await this.get('/api/dashboard/stats');
    },
    
    /**
     * 获取最近浏览记录
     */
    async getRecentBrowse(limit = 10) {
        return await this.get(`/api/browse/recent?limit=${limit}`);
    },
    
    /**
     * 获取最近下载记录
     */
    async getRecentDownloads(limit = 10) {
        return await this.get(`/api/downloads/recent?limit=${limit}`);
    },
    
    /**
     * 获取下载活动数据（用于图表）
     */
    async getDownloadActivity(days = 7) {
        return await this.get(`/api/downloads/activity?days=${days}`);
    },
    
    // ==================== 浏览记录 API ====================
    
    /**
     * 获取浏览记录列表
     */
    async getBrowseRecords(page = 1, pageSize = 20, search = '') {
        let url = `/api/browse?page=${page}&pageSize=${pageSize}`;
        if (search) {
            url += `&search=${encodeURIComponent(search)}`;
        }
        return await this.get(url);
    },
    
    /**
     * 获取浏览记录详情
     */
    async getBrowseDetail(id) {
        return await this.get(`/api/browse/${id}`);
    },
    
    /**
     * 删除浏览记录
     */
    async deleteBrowseRecords(ids) {
        return await this.post('/api/browse/delete', { ids });
    },
    
    /**
     * 导出浏览记录
     */
    async exportBrowseRecords(ids = []) {
        return await this.post('/api/browse/export', { ids });
    },
    
    // ==================== 下载记录 API ====================
    
    /**
     * 获取下载记录列表
     */
    async getDownloadRecords(page = 1, pageSize = 20, filters = {}) {
        let url = `/api/downloads?page=${page}&pageSize=${pageSize}`;
        if (filters.status) {
            url += `&status=${filters.status}`;
        }
        if (filters.startDate) {
            url += `&startDate=${filters.startDate}`;
        }
        if (filters.endDate) {
            url += `&endDate=${filters.endDate}`;
        }
        if (filters.search) {
            url += `&search=${encodeURIComponent(filters.search)}`;
        }
        return await this.get(url);
    },
    
    /**
     * 获取下载记录详情
     */
    async getDownloadDetail(id) {
        return await this.get(`/api/downloads/${id}`);
    },
    
    /**
     * 删除下载记录
     */
    async deleteDownloadRecords(ids) {
        return await this.post('/api/downloads/delete', { ids });
    },
    
    /**
     * 导出下载记录
     */
    async exportDownloadRecords(ids = []) {
        return await this.post('/api/downloads/export', { ids });
    },
    
    /**
     * 打开下载文件
     */
    async openDownloadFile(id) {
        return await this.post('/api/downloads/open', { id });
    },
    
    // ==================== 下载队列 API ====================
    
    /**
     * 获取下载队列
     */
    async getDownloadQueue() {
        return await this.get('/api/queue');
    },
    
    /**
     * 添加到下载队列
     */
    async addToQueue(items) {
        return await this.post('/api/queue/add', { items });
    },
    
    /**
     * 从浏览记录添加到队列
     */
    async addToQueueFromBrowse(ids) {
        return await this.post('/api/queue/add-from-browse', { ids });
    },
    
    /**
     * 暂停队列任务
     */
    async pauseQueueItem(id) {
        return await this.post('/api/queue/pause', { id });
    },
    
    /**
     * 恢复队列任务
     */
    async resumeQueueItem(id) {
        return await this.post('/api/queue/resume', { id });
    },
    
    /**
     * 移除队列任务
     */
    async removeQueueItem(id) {
        return await this.post('/api/queue/remove', { id });
    },
    
    /**
     * 批量暂停
     */
    async pauseAllQueue() {
        return await this.post('/api/queue/pause-all');
    },
    
    /**
     * 批量恢复
     */
    async resumeAllQueue() {
        return await this.post('/api/queue/resume-all');
    },
    
    /**
     * 清空队列
     */
    async clearQueue() {
        return await this.post('/api/queue/clear');
    },
    
    /**
     * 重排序队列
     */
    async reorderQueue(items) {
        return await this.post('/api/queue/reorder', { items });
    },
    
    // ==================== 批量下载 API ====================
    
    /**
     * 开始批量下载
     */
    async startBatchDownload(videos) {
        return await this.post('/api/batch/download', { videos });
    },
    
    /**
     * 获取批量下载进度
     */
    async getBatchProgress() {
        return await this.get('/api/batch/progress');
    },
    
    /**
     * 取消批量下载
     */
    async cancelBatchDownload() {
        return await this.post('/api/batch/cancel');
    },
    
    // ==================== 设置 API ====================
    
    /**
     * 获取设置
     */
    async getSettings() {
        return await this.get('/api/settings');
    },
    
    /**
     * 保存设置
     */
    async saveSettings(settings) {
        return await this.post('/api/settings', settings);
    },
    
    /**
     * 测试连接
     */
    async testConnection(url) {
        return await this.post('/api/settings/test', { url });
    },
    
    /**
     * 选择下载路径
     */
    async selectDownloadPath() {
        return await this.post('/api/settings/select-path');
    }
};

// 导出
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ApiClient;
}
