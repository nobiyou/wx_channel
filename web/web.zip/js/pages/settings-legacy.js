/**
 * 设置页面模块（兼容原 console.html）
 */

console.log('设置模块已加载（模块化版本）');

// 设置状态
var settingsState = {
    config: {},
    isSaving: false
};

// 加载设置
async function loadSettings() {
    try {
        // 从 localStorage 加载服务 URL
        const savedUrl = typeof StorageManager !== 'undefined' 
            ? StorageManager.loadServiceUrl() 
            : localStorage.getItem('serviceUrl') || 'http://127.0.0.1:2025';
        
        const urlInput = document.getElementById('settingServiceUrl');
        if (urlInput) {
            urlInput.value = savedUrl;
        }
        
        // 从服务器加载其他设置
        const result = await ApiClient.getSettings();
        if (result.success && result.data) {
            settingsState.config = result.data;
            renderSettings(result.data);
        }
    } catch (e) {
        console.error('加载设置失败:', e);
    }
}

// 渲染设置
function renderSettings(config) {
    // 下载路径
    const downloadPath = document.getElementById('settingDownloadPath');
    if (downloadPath && config.downloadPath) {
        downloadPath.value = config.downloadPath;
    }
    
    // 并发下载数
    const concurrent = document.getElementById('settingConcurrentDownloads');
    if (concurrent && config.concurrentDownloads) {
        concurrent.value = config.concurrentDownloads;
    }
    
    // 自动下载
    const autoDownload = document.getElementById('settingAutoDownload');
    if (autoDownload) {
        autoDownload.checked = config.autoDownload || false;
    }
    
    // 代理端口
    const proxyPort = document.getElementById('settingProxyPort');
    if (proxyPort && config.proxyPort) {
        proxyPort.value = config.proxyPort;
    }
    
    // Web 端口
    const webPort = document.getElementById('settingWebPort');
    if (webPort && config.webPort) {
        webPort.value = config.webPort;
    }
    
    // 文件名模板
    const filenameTemplate = document.getElementById('settingFilenameTemplate');
    if (filenameTemplate && config.filenameTemplate) {
        filenameTemplate.value = config.filenameTemplate;
    }
    
    // 按作者创建文件夹
    const createAuthorFolder = document.getElementById('settingCreateAuthorFolder');
    if (createAuthorFolder) {
        createAuthorFolder.checked = config.createAuthorFolder || false;
    }
}

// 保存设置
async function saveSettings() {
    if (settingsState.isSaving) return;
    settingsState.isSaving = true;
    
    try {
        // 收集设置
        const config = {
            downloadPath: document.getElementById('settingDownloadPath')?.value || '',
            concurrentDownloads: parseInt(document.getElementById('settingConcurrentDownloads')?.value) || 3,
            autoDownload: document.getElementById('settingAutoDownload')?.checked || false,
            proxyPort: parseInt(document.getElementById('settingProxyPort')?.value) || 9527,
            webPort: parseInt(document.getElementById('settingWebPort')?.value) || 9528,
            filenameTemplate: document.getElementById('settingFilenameTemplate')?.value || '{title}',
            createAuthorFolder: document.getElementById('settingCreateAuthorFolder')?.checked || false
        };
        
        // 保存服务 URL
        const serviceUrl = document.getElementById('settingServiceUrl')?.value;
        if (serviceUrl && typeof StorageManager !== 'undefined') {
            StorageManager.saveServiceUrl(serviceUrl);
        }
        
        // 保存其他设置到服务器
        const result = await ApiClient.saveSettings(config);
        if (result.success) {
            settingsState.config = config;
            if (typeof showMessage === 'function') {
                showMessage('设置已保存', 'success');
            }
        } else {
            if (typeof showMessage === 'function') {
                showMessage(result.error || '保存失败', 'error');
            }
        }
    } catch (e) {
        console.error('保存设置失败:', e);
        if (typeof showMessage === 'function') {
            showMessage('保存失败: ' + e.message, 'error');
        }
    } finally {
        settingsState.isSaving = false;
    }
}

// 连接到服务
function connectToService() {
    const serviceUrl = document.getElementById('settingServiceUrl')?.value;
    if (!serviceUrl) {
        if (typeof showMessage === 'function') {
            showMessage('请输入服务地址', 'error');
        }
        return;
    }
    
    if (typeof StorageManager !== 'undefined') {
        StorageManager.saveServiceUrl(serviceUrl);
    }
    
    if (typeof ConnectionManager !== 'undefined') {
        ConnectionManager.connect(serviceUrl);
    }
}

// 选择下载目录
async function selectDownloadPath() {
    try {
        const result = await ApiClient.selectFolder();
        if (result.success && result.data && result.data.path) {
            const downloadPath = document.getElementById('settingDownloadPath');
            if (downloadPath) {
                downloadPath.value = result.data.path;
            }
        }
    } catch (e) {
        console.error('选择目录失败:', e);
        if (typeof showMessage === 'function') {
            showMessage('选择目录失败: ' + e.message, 'error');
        }
    }
}

// 打开下载文件夹
async function openDownloadFolder() {
    try {
        const downloadPath = document.getElementById('settingDownloadPath')?.value;
        if (!downloadPath) {
            if (typeof showMessage === 'function') {
                showMessage('请先设置下载路径', 'error');
            }
            return;
        }
        
        const result = await ApiClient.openFolder(downloadPath);
        if (!result.success) {
            if (typeof showMessage === 'function') {
                showMessage(result.error || '打开文件夹失败', 'error');
            }
        }
    } catch (e) {
        console.error('打开文件夹失败:', e);
        if (typeof showMessage === 'function') {
            showMessage('打开文件夹失败: ' + e.message, 'error');
        }
    }
}

// 重置设置
function resetSettings() {
    if (!confirm('确定要重置所有设置吗？')) return;
    
    // 重置为默认值
    const defaults = {
        downloadPath: '',
        concurrentDownloads: 3,
        autoDownload: false,
        proxyPort: 9527,
        webPort: 9528,
        filenameTemplate: '{title}',
        createAuthorFolder: false
    };
    
    renderSettings(defaults);
    
    if (typeof showMessage === 'function') {
        showMessage('设置已重置，请点击保存按钮应用更改', 'info');
    }
}

// ============================================
// 验证函数
// ============================================

// 验证服务 URL
function validateServiceUrl() {
    const input = document.getElementById('settingServiceUrl');
    const errorDiv = document.getElementById('serviceUrlError');
    if (!input) return true;
    
    const value = input.value.trim();
    
    // 清除之前的状态
    input.classList.remove('error', 'valid');
    if (errorDiv) {
        errorDiv.classList.remove('visible');
        errorDiv.textContent = '';
    }
    
    if (!value) {
        input.classList.add('error');
        if (errorDiv) {
            errorDiv.textContent = '服务地址不能为空';
            errorDiv.classList.add('visible');
        }
        return false;
    }
    
    // 验证 URL 格式
    try {
        const url = new URL(value);
        if (url.protocol !== 'http:' && url.protocol !== 'https:') {
            throw new Error('Invalid protocol');
        }
        input.classList.add('valid');
        return true;
    } catch (e) {
        input.classList.add('error');
        if (errorDiv) {
            errorDiv.textContent = '请输入有效的 URL 地址（如 http://127.0.0.1:2025）';
            errorDiv.classList.add('visible');
        }
        return false;
    }
}

// 验证下载目录
function validateDownloadDir() {
    const input = document.getElementById('settingDownloadDir');
    const errorDiv = document.getElementById('downloadDirError');
    if (!input) return true;
    
    const value = input.value.trim();
    
    // 清除之前的状态
    input.classList.remove('error', 'valid');
    if (errorDiv) {
        errorDiv.classList.remove('visible');
        errorDiv.textContent = '';
    }
    
    // 空值允许（使用默认值）
    if (!value) {
        return true;
    }
    
    // 检查无效字符
    const invalidChars = /[<>:"|?*]/;
    if (invalidChars.test(value)) {
        input.classList.add('error');
        if (errorDiv) {
            errorDiv.textContent = '路径包含无效字符（< > : " | ? *）';
            errorDiv.classList.add('visible');
        }
        return false;
    }
    
    input.classList.add('valid');
    return true;
}

// 验证分片大小
function validateChunkSize() {
    const input = document.getElementById('settingChunkSize');
    const errorDiv = document.getElementById('chunkSizeError');
    if (!input) return true;
    
    const value = parseInt(input.value);
    
    // 清除之前的状态
    input.classList.remove('error', 'valid');
    if (errorDiv) {
        errorDiv.classList.remove('visible');
        errorDiv.textContent = '';
    }
    
    if (isNaN(value)) {
        input.classList.add('error');
        if (errorDiv) {
            errorDiv.textContent = '请输入有效的数字';
            errorDiv.classList.add('visible');
        }
        return false;
    }
    
    // 验证范围：1MB 到 100MB
    if (value < 1 || value > 100) {
        input.classList.add('error');
        if (errorDiv) {
            errorDiv.textContent = '分片大小必须在 1-100 MB 之间';
            errorDiv.classList.add('visible');
        }
        return false;
    }
    
    input.classList.add('valid');
    return true;
}

// 验证并发限制
function validateConcurrentLimit() {
    const input = document.getElementById('settingConcurrentLimit');
    const errorDiv = document.getElementById('concurrentLimitError');
    if (!input) return true;
    
    const value = parseInt(input.value);
    
    // 清除之前的状态
    input.classList.remove('error', 'valid');
    if (errorDiv) {
        errorDiv.classList.remove('visible');
        errorDiv.textContent = '';
    }
    
    if (isNaN(value)) {
        input.classList.add('error');
        if (errorDiv) {
            errorDiv.textContent = '请输入有效的数字';
            errorDiv.classList.add('visible');
        }
        return false;
    }
    
    // 验证范围：1 到 5
    if (value < 1 || value > 5) {
        input.classList.add('error');
        if (errorDiv) {
            errorDiv.textContent = '并发下载数必须在 1-5 之间';
            errorDiv.classList.add('visible');
        }
        return false;
    }
    
    input.classList.add('valid');
    return true;
}

// 验证自动清理天数
function validateAutoCleanupDays() {
    const input = document.getElementById('settingAutoCleanupDays');
    const errorDiv = document.getElementById('autoCleanupDaysError');
    if (!input) return true;
    
    const value = parseInt(input.value);
    
    // 清除之前的状态
    input.classList.remove('error', 'valid');
    if (errorDiv) {
        errorDiv.classList.remove('visible');
        errorDiv.textContent = '';
    }
    
    if (isNaN(value)) {
        input.classList.add('error');
        if (errorDiv) {
            errorDiv.textContent = '请输入有效的数字';
            errorDiv.classList.add('visible');
        }
        return false;
    }
    
    // 验证范围：1 到 365 天
    if (value < 1 || value > 365) {
        input.classList.add('error');
        if (errorDiv) {
            errorDiv.textContent = '清理天数必须在 1-365 天之间';
            errorDiv.classList.add('visible');
        }
        return false;
    }
    
    input.classList.add('valid');
    return true;
}

// 切换自动清理天数输入
function toggleAutoCleanupDays() {
    const checkbox = document.getElementById('settingAutoCleanup');
    const daysGroup = document.getElementById('autoCleanupDaysGroup');
    const daysInput = document.getElementById('settingAutoCleanupDays');
    
    if (!checkbox || !daysGroup || !daysInput) return;
    
    if (checkbox.checked) {
        daysGroup.classList.remove('disabled');
        daysInput.disabled = false;
    } else {
        daysGroup.classList.add('disabled');
        daysInput.disabled = true;
    }
}

// 测试连接
async function testConnection() {
    const serviceUrl = document.getElementById('settingServiceUrl')?.value.trim();
    
    if (!validateServiceUrl()) {
        return;
    }
    
    showMessage('正在测试连接...', 'info');
    
    try {
        const response = await fetch(`${serviceUrl}/api/health`, {
            method: 'GET',
            signal: AbortSignal.timeout(5000)
        });
        
        if (response.ok) {
            showMessage('连接成功！', 'success');
        } else {
            showMessage('连接失败：服务返回错误', 'error');
        }
    } catch (e) {
        showMessage('连接失败：' + (e.message || '无法连接到服务'), 'error');
    }
}

// 保存服务 URL
async function saveServiceUrl() {
    if (!validateServiceUrl()) {
        showMessage('请修正输入错误', 'error');
        return;
    }
    
    const serviceUrl = document.getElementById('settingServiceUrl')?.value.trim();
    
    // 保存到 localStorage
    if (typeof StorageManager !== 'undefined') {
        StorageManager.saveServiceUrl(serviceUrl);
    }
    
    // 如果 URL 改变，重新连接
    if (typeof ConnectionManager !== 'undefined' && serviceUrl !== ConnectionManager.serviceUrl) {
        ConnectionManager.connect(serviceUrl);
    }
    
    showMessage('服务地址已保存', 'success');
}
