/**
 * 批量下载模块 - Legacy版本
 * 负责批量下载视频的功能
 * 此模块覆盖console.html中的内联函数
 */

// 批量下载状态
var batchProgressInterval = null;

/**
 * 开始批量下载
 */
async function startBatchDownload() {
    const videoListText = document.getElementById('batchVideoList').value.trim();
    const forceRedownload = document.getElementById('forceRedownload').checked;

    if (!videoListText) {
        showMessage('请输入视频列表', 'error');
        return;
    }

    let videos;
    try {
        videos = JSON.parse(videoListText);
        if (!Array.isArray(videos)) {
            if (videos.videos && Array.isArray(videos.videos)) {
                videos = videos.videos;
            } else {
                throw new Error('Invalid format');
            }
        }
    } catch (e) {
        showMessage('JSON 格式错误: ' + e.message, 'error');
        return;
    }

    try {
        const result = await ApiClient.startBatchDownload(videos, forceRedownload);
        if (result.success) {
            showMessage(`下载任务已提交，共 ${videos.length} 个视频`, 'success');
            document.getElementById('batchProgressCard').style.display = 'block';
            startBatchProgressMonitoring();
        } else {
            showMessage('提交失败: ' + (result.error || '未知错误'), 'error');
        }
    } catch (e) {
        showMessage('请求失败: ' + e.message, 'error');
    }
}

/**
 * 开始监控批量下载进度
 */
function startBatchProgressMonitoring() {
    if (batchProgressInterval) {
        clearInterval(batchProgressInterval);
    }
    updateBatchProgress();
    batchProgressInterval = setInterval(updateBatchProgress, 2000);
}

/**
 * 更新批量下载进度
 */
async function updateBatchProgress() {
    try {
        const data = await ApiClient.getBatchProgress();
        if (data.success) {
            document.getElementById('batchTotal').textContent = data.total;
            document.getElementById('batchDone').textContent = data.done;
            document.getElementById('batchFailed').textContent = data.failed;
            document.getElementById('batchRunning').textContent = data.running;

            const percentage = data.total > 0 ? Math.round((data.done + data.failed) / data.total * 100) : 0;
            const progressBar = document.getElementById('batchProgressBar');
            progressBar.style.width = percentage + '%';
            progressBar.textContent = percentage + '%';

            if (data.done + data.failed === data.total && data.total > 0) {
                clearInterval(batchProgressInterval);
                batchProgressInterval = null;
                showMessage(`下载完成！成功: ${data.done}, 失败: ${data.failed}`, data.failed > 0 ? 'info' : 'success');
            }
        }
    } catch (e) {
        console.error('Failed to update batch progress:', e);
    }
}

/**
 * 取消批量下载
 */
async function cancelBatchDownload() {
    if (!confirm('确定要取消当前的下载任务吗？')) return;

    try {
        const result = await ApiClient.cancelBatchDownload();
        if (result.success) {
            showMessage('下载已取消', 'info');
            if (batchProgressInterval) {
                clearInterval(batchProgressInterval);
                batchProgressInterval = null;
            }
        } else {
            showMessage('取消失败: ' + (result.error || '未知错误'), 'error');
        }
    } catch (e) {
        showMessage('请求失败: ' + e.message, 'error');
    }
}

/**
 * 加载批量下载示例
 */
function loadBatchExample() {
    const example = [
        {
            id: "video_001",
            url: "https://example.com/video.mp4",
            title: "示例视频1",
            authorName: "示例作者"
        }
    ];
    document.getElementById('batchVideoList').value = JSON.stringify(example, null, 2);
    showMessage('已加载示例数据', 'info');
}
