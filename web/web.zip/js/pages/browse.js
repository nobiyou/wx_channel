/**
 * 浏览记录页面模块
 */

const BrowseState = {
    records: [],
    currentPage: 1,
    pageSize: 20,
    totalCount: 0,
    searchKeyword: '',
    sortBy: 'browse_time',
    sortOrder: 'desc',
    selectedIds: new Set()
};

// 初始化浏览记录页面
function initBrowsePage() {
    loadBrowseRecords(1);
}

// 加载浏览记录
async function loadBrowseRecords(page = 1) {
    try {
        showBrowseLoading();
        
        const params = {
            page,
            limit: BrowseState.pageSize,
            search: BrowseState.searchKeyword,
            sort_by: BrowseState.sortBy,
            sort_order: BrowseState.sortOrder
        };
        
        const response = await API.getBrowseRecords(params);
        
        BrowseState.records = response.records || [];
        BrowseState.currentPage = page;
        BrowseState.totalCount = response.total || 0;
        BrowseState.selectedIds.clear();
        
        renderBrowseRecords();
        
    } catch (error) {
        console.error('加载浏览记录失败:', error);
        showBrowseError('加载失败: ' + error.message);
    }
}

// 渲染浏览记录
function renderBrowseRecords() {
    const container = document.getElementById('browse-content');
    if (!container) return;
    
    if (BrowseState.records.length === 0 && !BrowseState.searchKeyword) {
        container.innerHTML = renderBrowseEmpty();
        return;
    }
    
    const totalPages = Math.ceil(BrowseState.totalCount / BrowseState.pageSize);
    
    container.innerHTML = `
        <div class="table-container">
            <div class="table-toolbar">
                <div class="table-toolbar-left">
                    <div class="table-search">
                        <svg class="table-search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
                        </svg>
                        <input type="search" id="browse-search" placeholder="搜索标题、作者..." value="${escapeHtml(BrowseState.searchKeyword)}">
                    </div>
                </div>
                <div class="table-toolbar-right">
                    <select id="browse-sort" class="form-select">
                        <option value="browse_time" ${BrowseState.sortBy === 'browse_time' ? 'selected' : ''}>按浏览时间</option>
                        <option value="title" ${BrowseState.sortBy === 'title' ? 'selected' : ''}>按标题</option>
                        <option value="author" ${BrowseState.sortBy === 'author' ? 'selected' : ''}>按作者</option>
                    </select>
                    <button class="btn btn-secondary btn-icon" onclick="toggleBrowseSortOrder()" title="${BrowseState.sortOrder === 'desc' ? '降序' : '升序'}">
                        ${BrowseState.sortOrder === 'desc' ? '↓' : '↑'}
                    </button>
                    <button class="btn btn-secondary" onclick="loadBrowseRecords(1)">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:16px;height:16px">
                            <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
                            <path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"/>
                        </svg>
                        刷新
                    </button>
                </div>
            </div>
            
            <div id="browse-batch-actions" class="batch-actions ${BrowseState.selectedIds.size > 0 ? 'active' : ''}">
                <span class="batch-actions-info">已选择 <span id="browse-selected-count">${BrowseState.selectedIds.size}</span> 项</span>
                <div class="batch-actions-buttons">
                    <button class="btn btn-primary btn-sm" onclick="addSelectedToQueue()">添加到队列</button>
                    <button class="btn btn-danger btn-sm" onclick="deleteSelectedBrowseRecords()">删除</button>
                </div>
            </div>
            
            <table class="table">
                <thead>
                    <tr>
                        <th width="40"><input type="checkbox" id="browse-select-all" onchange="toggleBrowseSelectAll(this.checked)"></th>
                        <th width="80">封面</th>
                        <th>标题</th>
                        <th width="120">作者</th>
                        <th width="80">时长</th>
                        <th width="140">浏览时间</th>
                        <th width="100">操作</th>
                    </tr>
                </thead>
                <tbody>
                    ${BrowseState.records.length > 0 
                        ? BrowseState.records.map(record => renderBrowseRow(record)).join('')
                        : '<tr><td colspan="7" class="table-empty">没有找到匹配的记录</td></tr>'
                    }
                </tbody>
            </table>
            
            ${totalPages > 1 ? `
            <div class="pagination">
                <div class="pagination-info">共 ${BrowseState.totalCount} 条，第 ${BrowseState.currentPage}/${totalPages} 页</div>
                <div class="pagination-controls">
                    <button class="pagination-btn" ${BrowseState.currentPage <= 1 ? 'disabled' : ''} onclick="loadBrowseRecords(${BrowseState.currentPage - 1})">上一页</button>
                    <span class="pagination-current">${BrowseState.currentPage}</span>
                    <button class="pagination-btn" ${BrowseState.currentPage >= totalPages ? 'disabled' : ''} onclick="loadBrowseRecords(${BrowseState.currentPage + 1})">下一页</button>
                </div>
            </div>
            ` : ''}
        </div>
    `;
    
    // 绑定搜索事件
    const searchInput = document.getElementById('browse-search');
    if (searchInput) {
        searchInput.addEventListener('input', debounce((e) => {
            BrowseState.searchKeyword = e.target.value;
            loadBrowseRecords(1);
        }, 300));
    }
    
    // 绑定排序事件
    const sortSelect = document.getElementById('browse-sort');
    if (sortSelect) {
        sortSelect.addEventListener('change', (e) => {
            BrowseState.sortBy = e.target.value;
            loadBrowseRecords(1);
        });
    }
}

// 渲染浏览记录行
function renderBrowseRow(record) {
    const isSelected = BrowseState.selectedIds.has(record.id);
    const coverUrl = record.cover_url || record.coverUrl || '';
    
    return `
        <tr class="${isSelected ? 'selected' : ''}" data-id="${record.id}">
            <td><input type="checkbox" ${isSelected ? 'checked' : ''} onchange="toggleBrowseSelect('${record.id}')"></td>
            <td>
                ${coverUrl 
                    ? `<img src="${coverUrl}" class="table-thumbnail" onclick="openLightbox('${escapeHtml(coverUrl)}', '${escapeHtml(record.title || '')}')" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 60 40%22><rect fill=%22%23f0f0f0%22 width=%2260%22 height=%2240%22/></svg>'">`
                    : '<div class="table-thumbnail-placeholder"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg></div>'
                }
            </td>
            <td>
                <div class="table-title" title="${escapeHtml(record.title || '')}">${escapeHtml(record.title || '无标题')}</div>
            </td>
            <td><span class="table-author">${escapeHtml(record.author || record.nickname || '-')}</span></td>
            <td><span class="table-meta">${record.duration ? formatDuration(record.duration) : '-'}</span></td>
            <td><span class="table-meta">${formatRelativeTime(record.browse_time || record.browseTime)}</span></td>
            <td>
                <div class="table-actions">
                    <button class="btn btn-sm btn-primary" onclick="addBrowseToQueue('${record.id}')" title="添加到队列">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
                        </svg>
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteBrowseRecord('${record.id}')" title="删除">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px">
                            <polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                        </svg>
                    </button>
                </div>
            </td>
        </tr>
    `;
}

function showBrowseLoading() {
    const container = document.getElementById('browse-content');
    if (container) {
        container.innerHTML = '<div class="loading-state"><div class="loading-spinner"></div><p>加载中...</p></div>';
    }
}

function showBrowseError(message) {
    const container = document.getElementById('browse-content');
    if (container) {
        container.innerHTML = `<div class="empty-state"><h3>加载失败</h3><p>${escapeHtml(message)}</p><button class="btn btn-primary" onclick="loadBrowseRecords(1)">重试</button></div>`;
    }
}

function renderBrowseEmpty() {
    return `
        <div class="empty-state">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>
            </svg>
            <h3>暂无浏览记录</h3>
            <p>开始浏览视频后，记录会显示在这里</p>
        </div>
    `;
}

// 选择相关
function toggleBrowseSelect(id) {
    if (BrowseState.selectedIds.has(id)) {
        BrowseState.selectedIds.delete(id);
    } else {
        BrowseState.selectedIds.add(id);
    }
    updateBrowseBatchActions();
}

function toggleBrowseSelectAll(checked) {
    if (checked) {
        BrowseState.records.forEach(r => BrowseState.selectedIds.add(r.id));
    } else {
        BrowseState.selectedIds.clear();
    }
    renderBrowseRecords();
}

function toggleBrowseSortOrder() {
    BrowseState.sortOrder = BrowseState.sortOrder === 'desc' ? 'asc' : 'desc';
    loadBrowseRecords(1);
}

function updateBrowseBatchActions() {
    const batchActions = document.getElementById('browse-batch-actions');
    const selectedCount = document.getElementById('browse-selected-count');
    const selectAll = document.getElementById('browse-select-all');
    
    if (batchActions) {
        batchActions.classList.toggle('active', BrowseState.selectedIds.size > 0);
    }
    if (selectedCount) {
        selectedCount.textContent = BrowseState.selectedIds.size;
    }
    if (selectAll) {
        selectAll.checked = BrowseState.selectedIds.size === BrowseState.records.length && BrowseState.records.length > 0;
    }
    
    // 更新行选中状态
    document.querySelectorAll('#browse-content tbody tr').forEach(tr => {
        const id = tr.dataset.id;
        const checkbox = tr.querySelector('input[type="checkbox"]');
        if (id && checkbox) {
            const isSelected = BrowseState.selectedIds.has(id);
            tr.classList.toggle('selected', isSelected);
            checkbox.checked = isSelected;
        }
    });
}

// 操作函数
async function addBrowseToQueue(id) {
    try {
        await API.addToQueueFromBrowse(id);
        Toast.success('已添加到下载队列');
    } catch (error) {
        Toast.error('添加失败: ' + error.message);
    }
}

async function addSelectedToQueue() {
    if (BrowseState.selectedIds.size === 0) return;
    
    try {
        const ids = Array.from(BrowseState.selectedIds);
        await API.batchAddToQueue(ids);
        Toast.success(`已添加 ${ids.length} 个视频到队列`);
        BrowseState.selectedIds.clear();
        updateBrowseBatchActions();
    } catch (error) {
        Toast.error('批量添加失败: ' + error.message);
    }
}

async function deleteBrowseRecord(id) {
    const confirmed = await Modal.confirm({
        title: '确认删除',
        message: '确定要删除这条浏览记录吗？',
        type: 'danger'
    });
    
    if (confirmed) {
        try {
            await API.deleteBrowseRecord(id);
            Toast.success('删除成功');
            loadBrowseRecords(BrowseState.currentPage);
        } catch (error) {
            Toast.error('删除失败: ' + error.message);
        }
    }
}

async function deleteSelectedBrowseRecords() {
    if (BrowseState.selectedIds.size === 0) return;
    
    const confirmed = await Modal.confirm({
        title: '批量删除',
        message: `确定要删除选中的 ${BrowseState.selectedIds.size} 条记录吗？`,
        type: 'danger'
    });
    
    if (confirmed) {
        try {
            await API.deleteBrowseRecords(Array.from(BrowseState.selectedIds));
            Toast.success('批量删除成功');
            loadBrowseRecords(BrowseState.currentPage);
        } catch (error) {
            Toast.error('批量删除失败: ' + error.message);
        }
    }
}
