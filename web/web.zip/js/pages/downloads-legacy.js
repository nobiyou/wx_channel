/**
 * 下载记录页面模块（兼容原 console.html）
 * 从 console.html 提取并模块化
 */

console.log('下载记录模块已加载（模块化版本）');

// 下载记录状态
var downloadState = {
    records: [],
    currentPage: 1,
    pageSize: 20,
    totalCount: 0,
    totalPages: 0,
    statusFilter: '',
    dateStart: '',
    dateEnd: '',
    selectedIds: new Set(),
    currentDetailId: null
};

// 加载下载记录（覆盖原函数）
async function loadDownloadRecords() {
    if (typeof ConnectionManager !== 'undefined' && ConnectionManager.getStatus() !== 'connected') {
        renderDownloadEmptyState('请先连接到本地服务');
        return;
    }

    try {
        const params = {
            page: downloadState.currentPage,
            pageSize: downloadState.pageSize
        };
        
        // 添加状态筛选
        if (downloadState.statusFilter) {
            params.status = downloadState.statusFilter;
        }
        
        // 添加日期范围筛选
        if (downloadState.dateStart) {
            params.startDate = downloadState.dateStart;
        }
        if (downloadState.dateEnd) {
            params.endDate = downloadState.dateEnd;
        }

        const result = await ApiClient.getDownloadRecords(params);
        
        if (result.success) {
            const data = result.data || {};
            downloadState.records = data.items || [];
            downloadState.totalCount = data.total || 0;
            downloadState.totalPages = data.totalPages || Math.ceil(downloadState.totalCount / downloadState.pageSize);
            
            renderDownloadTable();
            renderDownloadPagination();
            updateDownloadBatchActions();
        } else {
            renderDownloadEmptyState('加载失败: ' + (result.error || '未知错误'));
        }
    } catch (e) {
        console.error('加载下载记录失败:', e);
        renderDownloadEmptyState('加载失败: ' + e.message);
    }
}

// 渲染下载记录表格
function renderDownloadTable() {
    const tbody = document.getElementById('downloadTableBody');
    if (!tbody) return;
    
    if (!downloadState.records || downloadState.records.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="11">
                    <div class="table-empty-state">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                            <polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
                        </svg>
                        <p>${hasDownloadFilters() ? '没有找到匹配的记录' : '暂无下载记录'}</p>
                    </div>
                </td>
            </tr>
        `;
        return;
    }

    let html = '';
    for (const record of downloadState.records) {
        const isSelected = downloadState.selectedIds.has(record.id);
        const statusClass = record.status || 'completed';
        const statusText = getStatusText(record.status);
        
        // 封面图处理
        const thumbnail = record.coverUrl 
            ? `<img class="table-thumbnail" src="${escapeHtml(record.coverUrl)}" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"><div class="table-thumbnail-placeholder" style="display:none"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></div>`
            : `<div class="table-thumbnail-placeholder"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg></div>`;
        
        html += `
            <tr class="${isSelected ? 'selected' : ''} ${record.status === 'failed' ? 'error-row' : ''}" data-id="${escapeHtml(record.id)}">
                <td onclick="event.stopPropagation();">
                    <input type="checkbox" ${isSelected ? 'checked' : ''} onchange="toggleDownloadSelect('${escapeHtml(record.id)}', this.checked)">
                </td>
                <td onclick="showDownloadDetail('${escapeHtml(record.id)}')">${thumbnail}</td>
                <td onclick="showDownloadDetail('${escapeHtml(record.id)}')">
                    <div class="table-title" title="${escapeHtml(record.title || '无标题')}">${escapeHtml(record.title || '无标题')}</div>
                    ${record.errorMessage ? `<div class="table-error-hint" title="${escapeHtml(record.errorMessage)}">⚠ ${escapeHtml(record.errorMessage.substring(0, 30))}${record.errorMessage.length > 30 ? '...' : ''}</div>` : ''}
                </td>
                <td onclick="showDownloadDetail('${escapeHtml(record.id)}')">
                    <span class="table-author">${escapeHtml(record.author || '未知')}</span>
                </td>
                <td onclick="showDownloadDetail('${escapeHtml(record.id)}')">
                    <span class="table-meta">${record.duration ? formatDuration(record.duration) : '-'}</span>
                </td>
                <td onclick="showDownloadDetail('${escapeHtml(record.id)}')">
                    <span class="table-meta">${escapeHtml(record.resolution || '-')}</span>
                </td>
                <td onclick="showDownloadDetail('${escapeHtml(record.id)}')">
                    <span class="table-meta">${record.fileSize ? formatBytes(record.fileSize) : '-'}</span>
                </td>
                <td onclick="showDownloadDetail('${escapeHtml(record.id)}')">
                    <span class="table-meta">${escapeHtml(record.format || '-')}</span>
                </td>
                <td onclick="showDownloadDetail('${escapeHtml(record.id)}')">
                    <span class="table-meta">${record.downloadTime ? formatDateTime(record.downloadTime) : '-'}</span>
                </td>
                <td onclick="showDownloadDetail('${escapeHtml(record.id)}')">
                    <span class="download-status ${statusClass}">${statusText}</span>
                </td>
                <td onclick="event.stopPropagation();">
                    <div class="table-actions">
                        ${record.status === 'completed' ? `
                        <button class="table-action-btn" onclick="playDownloadedVideo('${escapeHtml(record.id)}')" title="播放视频">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polygon points="5 3 19 12 5 21 5 3"/>
                            </svg>
                        </button>
                        <button class="table-action-btn" onclick="openDownloadFolder('${escapeHtml(record.id)}')" title="打开文件夹">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
                            </svg>
                        </button>
                        ` : ''}
                        ${record.status === 'failed' ? `
                        <button class="table-action-btn" onclick="retryDownload('${escapeHtml(record.id)}')" title="重试下载">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
                                <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
                            </svg>
                        </button>
                        ` : ''}
                        <button class="table-action-btn" onclick="deleteDownloadRecord('${escapeHtml(record.id)}')" title="删除">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                            </svg>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }
    
    tbody.innerHTML = html;
}

// 渲染空状态
function renderDownloadEmptyState(message) {
    const tbody = document.getElementById('downloadTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = `
        <tr>
            <td colspan="11">
                <div class="table-empty-state">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"/>
                        <line x1="12" y1="8" x2="12" y2="12"/>
                        <line x1="12" y1="16" x2="12.01" y2="16"/>
                    </svg>
                    <p>${escapeHtml(message)}</p>
                </div>
            </td>
        </tr>
    `;
}

// 渲染分页
function renderDownloadPagination() {
    const container = document.getElementById('downloadPagination');
    if (!container) return;
    
    if (downloadState.totalPages <= 1) {
        container.innerHTML = downloadState.totalCount > 0 
            ? `<span class="pagination-info">共 ${downloadState.totalCount} 条记录</span>`
            : '';
        return;
    }

    let html = '';
    
    // 上一页按钮
    html += `<button ${downloadState.currentPage === 1 ? 'disabled' : ''} onclick="goToDownloadPage(${downloadState.currentPage - 1})">上一页</button>`;
    
    // 页码
    const maxVisiblePages = 5;
    let startPage = Math.max(1, downloadState.currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(downloadState.totalPages, startPage + maxVisiblePages - 1);
    
    if (endPage - startPage < maxVisiblePages - 1) {
        startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }
    
    if (startPage > 1) {
        html += `<button onclick="goToDownloadPage(1)">1</button>`;
        if (startPage > 2) {
            html += '<span>...</span>';
        }
    }
    
    for (let i = startPage; i <= endPage; i++) {
        html += `<button class="${i === downloadState.currentPage ? 'active' : ''}" onclick="goToDownloadPage(${i})">${i}</button>`;
    }
    
    if (endPage < downloadState.totalPages) {
        if (endPage < downloadState.totalPages - 1) {
            html += '<span>...</span>';
        }
        html += `<button onclick="goToDownloadPage(${downloadState.totalPages})">${downloadState.totalPages}</button>`;
    }
    
    // 下一页按钮
    html += `<button ${downloadState.currentPage === downloadState.totalPages ? 'disabled' : ''} onclick="goToDownloadPage(${downloadState.currentPage + 1})">下一页</button>`;
    
    // 信息
    html += `<span class="pagination-info">共 ${downloadState.totalCount} 条记录</span>`;
    
    container.innerHTML = html;
}

// 检查是否有筛选条件
function hasDownloadFilters() {
    return downloadState.statusFilter || downloadState.dateStart || downloadState.dateEnd;
}

// 切换页码
function goToDownloadPage(page) {
    if (page < 1 || page > downloadState.totalPages || page === downloadState.currentPage) return;
    downloadState.currentPage = page;
    loadDownloadRecords();
}

// 筛选状态
function filterDownloadByStatus(status) {
    downloadState.statusFilter = status;
    downloadState.currentPage = 1;
    loadDownloadRecords();
}

// 筛选日期
function filterDownloadByDate(startDate, endDate) {
    downloadState.dateStart = startDate;
    downloadState.dateEnd = endDate;
    downloadState.currentPage = 1;
    loadDownloadRecords();
}

// 清除筛选
function clearDownloadFilters() {
    downloadState.statusFilter = '';
    downloadState.dateStart = '';
    downloadState.dateEnd = '';
    downloadState.currentPage = 1;
    
    // 清除UI
    const statusFilter = document.getElementById('downloadStatusFilter');
    if (statusFilter) statusFilter.value = '';
    
    const dateStart = document.getElementById('downloadDateStart');
    if (dateStart) dateStart.value = '';
    
    const dateEnd = document.getElementById('downloadDateEnd');
    if (dateEnd) dateEnd.value = '';
    
    loadDownloadRecords();
}

// 选择操作
function toggleDownloadSelect(id, checked) {
    if (checked) {
        downloadState.selectedIds.add(id);
    } else {
        downloadState.selectedIds.delete(id);
    }
    updateDownloadBatchActions();
}

function toggleDownloadSelectAll(checked) {
    if (checked) {
        downloadState.records.forEach(r => downloadState.selectedIds.add(r.id));
    } else {
        downloadState.selectedIds.clear();
    }
    renderDownloadTable();
    updateDownloadBatchActions();
}

// 更新批量操作栏
function updateDownloadBatchActions() {
    const batchBar = document.getElementById('downloadBatchActionsBar');
    const selectedCount = document.getElementById('downloadSelectedCount');
    
    if (batchBar) {
        batchBar.style.display = downloadState.selectedIds.size > 0 ? 'flex' : 'none';
    }
    
    if (selectedCount) {
        selectedCount.textContent = downloadState.selectedIds.size;
    }
}

// 显示详情
function showDownloadDetail(id) {
    downloadState.currentDetailId = id;
    const record = downloadState.records.find(r => r.id === id);
    if (!record) return;
    
    console.log('显示下载记录详情:', record);
    // TODO: 实现详情面板
}

// 播放视频
async function playDownloadedVideo(id) {
    try {
        const response = await ApiClient.playDownloadedVideo(id);
        if (!response.success) {
            if (typeof showMessage === 'function') {
                showMessage(response.error || '播放失败', 'error');
            }
        }
    } catch (e) {
        console.error('播放视频失败:', e);
        if (typeof showMessage === 'function') {
            showMessage('播放失败: ' + e.message, 'error');
        }
    }
}

// 打开文件夹
async function openDownloadFolder(id) {
    const record = downloadState.records.find(r => r.id === id);
    if (record && record.filePath) {
        try {
            // 调用后端API打开文件夹
            const result = await ApiClient.openFolder(record.filePath);
            if (result.success) {
                if (typeof showMessage === 'function') {
                    showMessage('已打开文件夹', 'success');
                }
            } else {
                // 如果后端不支持，显示文件路径
                if (typeof showMessage === 'function') {
                    showMessage('文件路径: ' + record.filePath, 'info');
                }
            }
        } catch (e) {
            console.error('打开文件夹失败:', e);
            // 后端可能不支持此功能，显示文件路径
            if (typeof showMessage === 'function') {
                showMessage('文件路径: ' + record.filePath, 'info');
            }
        }
    } else {
        if (typeof showMessage === 'function') {
            showMessage('文件路径不可用', 'error');
        }
    }
}

// 重试下载
async function retryDownload(id) {
    try {
        const response = await ApiClient.retryDownload(id);
        if (response.success) {
            if (typeof showMessage === 'function') {
                showMessage('已重新加入下载队列', 'success');
            }
            loadDownloadRecords();
        } else {
            if (typeof showMessage === 'function') {
                showMessage(response.error || '重试失败', 'error');
            }
        }
    } catch (e) {
        console.error('重试下载失败:', e);
        if (typeof showMessage === 'function') {
            showMessage('重试失败: ' + e.message, 'error');
        }
    }
}

// 删除记录
async function deleteDownloadRecord(id) {
    if (!confirm('确定要删除这条下载记录吗？（不会删除已下载的文件）')) return;
    
    try {
        const response = await ApiClient.deleteDownloadRecord(id);
        if (response.success) {
            if (typeof showMessage === 'function') {
                showMessage('删除成功', 'success');
            }
            downloadState.selectedIds.delete(id);
            loadDownloadRecords();
        } else {
            if (typeof showMessage === 'function') {
                showMessage(response.error || '删除失败', 'error');
            }
        }
    } catch (e) {
        console.error('删除下载记录失败:', e);
        if (typeof showMessage === 'function') {
            showMessage('删除失败: ' + e.message, 'error');
        }
    }
}

// 批量删除
async function deleteSelectedDownloadRecords() {
    if (downloadState.selectedIds.size === 0) return;
    if (!confirm(`确定要删除选中的 ${downloadState.selectedIds.size} 条记录吗？（不会删除已下载的文件）`)) return;
    
    try {
        const ids = Array.from(downloadState.selectedIds);
        const response = await ApiClient.deleteDownloadRecords(ids);
        if (response.success) {
            if (typeof showMessage === 'function') {
                showMessage('批量删除成功', 'success');
            }
            downloadState.selectedIds.clear();
            loadDownloadRecords();
        } else {
            if (typeof showMessage === 'function') {
                showMessage(response.error || '批量删除失败', 'error');
            }
        }
    } catch (e) {
        console.error('批量删除下载记录失败:', e);
        if (typeof showMessage === 'function') {
            showMessage('批量删除失败: ' + e.message, 'error');
        }
    }
}
