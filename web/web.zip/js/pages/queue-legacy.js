/**
 * 下载队列页面模块 - Legacy版本
 * 负责下载队列管理功能
 * 此模块覆盖console.html中的内联函数
 */

console.log('下载队列模块已加载（模块化版本）');

// 队列状态
var queueState = {
    items: [],
    isProcessing: false,
    draggedIndex: -1,
    draggedItem: null
};

// 加载下载队列
async function loadDownloadQueue() {
    if (typeof ConnectionManager !== 'undefined' && ConnectionManager.getStatus() !== 'connected') {
        renderQueueEmptyState('请先连接到本地服务');
        return;
    }

    try {
        const result = await ApiClient.getDownloadQueue();
        
        if (result.success) {
            queueState.items = result.data || [];
            queueState.isProcessing = result.isProcessing || false;
            
            renderDownloadQueue();
        } else {
            renderQueueEmptyState(result.error || '加载失败');
        }
    } catch (e) {
        console.error('加载下载队列失败:', e);
        renderQueueEmptyState('加载失败: ' + e.message);
    }
}

// 渲染下载队列（使用原有的renderQueueList名称）
function renderQueueList() {
    const container = document.getElementById('downloadQueueList');
    if (!container) return;
    
    if (!queueState.items || queueState.items.length === 0) {
        container.innerHTML = `
            <div class="queue-empty-state">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/>
                    <line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/>
                    <line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>
                </svg>
                <p>下载队列为空</p>
                <p style="margin-top: 8px; font-size: 12px;">从浏览记录中选择视频添加到队列</p>
            </div>
        `;
        return;
    }

    let html = '';
    for (let i = 0; i < queueState.items.length; i++) {
        const item = queueState.items[i];
        html += renderQueueItem(item, i);
    }
    
    container.innerHTML = html;
    setupDragAndDrop();
}

// 渲染单个队列项
function renderQueueItem(item, index) {
    const statusClass = item.status || 'pending';
    const statusText = getQueueStatusText(item.status);
    const progress = calculateProgress(item);
    const progressClass = item.status === 'paused' ? 'paused' : (item.status === 'failed' ? 'failed' : '');
    
    const speedText = item.speed > 0 ? formatSpeed(item.speed) : '-';
    const etaText = calculateETA(item);
    const downloadedText = formatBytes(item.downloadedSize || 0);
    const totalText = formatBytes(item.totalSize || 0);
    
    return `
        <div class="queue-item" 
             data-id="${escapeHtml(item.id)}" 
             data-index="${index}"
             draggable="true"
             ondragstart="handleDragStart(event, ${index})"
             ondragend="handleDragEnd(event)"
             ondragover="handleDragOver(event)"
             ondragleave="handleDragLeave(event)"
             ondrop="handleDrop(event, ${index})">
            
            <div class="queue-item-drag-handle" title="拖拽排序">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="8" y1="6" x2="8" y2="6.01"/><line x1="12" y1="6" x2="12" y2="6.01"/><line x1="16" y1="6" x2="16" y2="6.01"/>
                    <line x1="8" y1="12" x2="8" y2="12.01"/><line x1="12" y1="12" x2="12" y2="12.01"/><line x1="16" y1="12" x2="16" y2="12.01"/>
                    <line x1="8" y1="18" x2="8" y2="18.01"/><line x1="12" y1="18" x2="12" y2="18.01"/><line x1="16" y1="18" x2="16" y2="18.01"/>
                </svg>
            </div>
            
            <div class="queue-item-info">
                <div class="queue-item-title" title="${escapeHtml(item.title || '无标题')}">${escapeHtml(item.title || '无标题')}</div>
                <div class="queue-item-meta">
                    <span>${escapeHtml(item.author || '未知作者')}</span>
                    ${item.totalSize ? `<span>${totalText}</span>` : ''}
                </div>
            </div>
            
            <div class="queue-item-progress">
                <div class="queue-progress-bar">
                    <div class="queue-progress-fill ${progressClass}" style="width: ${progress}%"></div>
                </div>
                <div class="queue-progress-text">
                    <span>${downloadedText} / ${totalText}</span>
                    <span>${progress.toFixed(1)}%</span>
                </div>
            </div>
            
            <div style="width: 100px; text-align: center; flex-shrink: 0;">
                <div style="font-size: 13px; color: var(--text-primary);">${speedText}</div>
                <div style="font-size: 11px; color: var(--text-secondary);">${etaText}</div>
            </div>
            
            <span class="queue-item-status ${statusClass}">${statusText}</span>
            
            <div class="queue-item-actions">
                ${item.status === 'pending' ? `
                <button class="queue-action-btn primary" onclick="startQueueItemDownload('${escapeHtml(item.id)}')" title="开始下载">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                        <polyline points="7 10 12 15 17 10"/>
                        <line x1="12" y1="15" x2="12" y2="3"/>
                    </svg>
                </button>
                ` : ''}
                ${item.status === 'downloading' ? `
                <button class="queue-action-btn" onclick="pauseQueueItem('${escapeHtml(item.id)}')" title="暂停">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/>
                    </svg>
                </button>
                ` : ''}
                ${item.status === 'paused' ? `
                <button class="queue-action-btn" onclick="resumeQueueItem('${escapeHtml(item.id)}')" title="恢复">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polygon points="5 3 19 12 5 21 5 3"/>
                    </svg>
                </button>
                ` : ''}
                ${item.status === 'failed' ? `
                <button class="queue-action-btn" onclick="retryQueueItem('${escapeHtml(item.id)}')" title="重试">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
                        <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>
                    </svg>
                </button>
                ` : ''}
                <button class="queue-action-btn danger" onclick="removeQueueItem('${escapeHtml(item.id)}')" title="移除">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                    </svg>
                </button>
            </div>
        </div>
    `;
}

// 兼容旧函数名
function renderDownloadQueue() {
    renderQueueList();
}

// 渲染空状态
function renderQueueEmptyState(message) {
    const container = document.getElementById('downloadQueueList');
    if (!container) return;
    
    container.innerHTML = `
        <div class="table-empty-state">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/>
                <line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>
            </svg>
            <p>${escapeHtml(message)}</p>
        </div>
    `;
}

// 获取队列状态文本
function getQueueStatusText(status) {
    const statusMap = {
        'pending': '等待中',
        'downloading': '下载中',
        'completed': '已完成',
        'failed': '失败',
        'paused': '已暂停'
    };
    return statusMap[status] || status || '未知';
}

// 开始/暂停队列处理
async function toggleQueueProcessing() {
    try {
        const response = queueState.isProcessing 
            ? await ApiClient.pauseQueue()
            : await ApiClient.startQueue();
        
        if (response.success) {
            if (typeof showMessage === 'function') {
                showMessage(queueState.isProcessing ? '队列已暂停' : '队列开始处理', 'success');
            }
            loadDownloadQueue();
        } else {
            if (typeof showMessage === 'function') {
                showMessage(response.error || '操作失败', 'error');
            }
        }
    } catch (e) {
        console.error('队列操作失败:', e);
        if (typeof showMessage === 'function') {
            showMessage('操作失败: ' + e.message, 'error');
        }
    }
}

// 重试队列项
async function retryQueueItem(id) {
    try {
        const response = await ApiClient.retryQueueItem(id);
        if (response.success) {
            if (typeof showMessage === 'function') {
                showMessage('已重新加入队列', 'success');
            }
            loadDownloadQueue();
        } else {
            if (typeof showMessage === 'function') {
                showMessage(response.error || '重试失败', 'error');
            }
        }
    } catch (e) {
        console.error('重试失败:', e);
        if (typeof showMessage === 'function') {
            showMessage('重试失败: ' + e.message, 'error');
        }
    }
}

// 移除队列项
async function removeQueueItem(id) {
    if (!confirm('确定要从队列中移除这个项目吗？')) return;
    
    try {
        const response = await ApiClient.removeFromQueue(id);
        if (response.success) {
            if (typeof showMessage === 'function') {
                showMessage('已移除', 'success');
            }
            loadDownloadQueue();
        } else {
            if (typeof showMessage === 'function') {
                showMessage(response.error || '移除失败', 'error');
            }
        }
    } catch (e) {
        console.error('移除失败:', e);
        if (typeof showMessage === 'function') {
            showMessage('移除失败: ' + e.message, 'error');
        }
    }
}

// 计算进度百分比
function calculateProgress(item) {
    if (!item.totalSize || item.totalSize === 0) return 0;
    return Math.min(100, (item.downloadedSize || 0) / item.totalSize * 100);
}

// 格式化下载速度
function formatSpeed(bytesPerSecond) {
    if (!bytesPerSecond || bytesPerSecond <= 0) return '-';
    return formatBytes(bytesPerSecond) + '/s';
}

// 计算预计剩余时间
function calculateETA(item) {
    if (!item.speed || item.speed <= 0) return '-';
    if (!item.totalSize || !item.downloadedSize) return '-';
    
    const remaining = item.totalSize - item.downloadedSize;
    if (remaining <= 0) return '完成';
    
    const seconds = Math.ceil(remaining / item.speed);
    
    if (seconds < 60) return `${seconds}秒`;
    if (seconds < 3600) return `${Math.ceil(seconds / 60)}分钟`;
    return `${Math.floor(seconds / 3600)}小时${Math.ceil((seconds % 3600) / 60)}分`;
}

// 更新队列统计
function updateQueueStats() {
    const total = queueState.items.length;
    const downloading = queueState.items.filter(i => i.status === 'downloading').length;
    const pending = queueState.items.filter(i => i.status === 'pending').length;
    const paused = queueState.items.filter(i => i.status === 'paused').length;
    
    const totalEl = document.getElementById('queueTotalCount');
    const downloadingEl = document.getElementById('queueDownloadingCount');
    const pendingEl = document.getElementById('queuePendingCount');
    const pausedEl = document.getElementById('queuePausedCount');
    
    if (totalEl) totalEl.textContent = total;
    if (downloadingEl) downloadingEl.textContent = downloading;
    if (pendingEl) pendingEl.textContent = pending;
    if (pausedEl) pausedEl.textContent = paused;
}

// ============================================
// 拖拽排序功能
// ============================================

function setupDragAndDrop() {
    // 事件监听器已在HTML中内联添加
}

function handleDragStart(event, index) {
    queueState.draggedIndex = index;
    queueState.draggedItem = queueState.items[index];
    event.target.classList.add('dragging');
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('text/plain', index.toString());
}

function handleDragEnd(event) {
    event.target.classList.remove('dragging');
    queueState.draggedIndex = -1;
    queueState.draggedItem = null;
    
    document.querySelectorAll('.queue-item').forEach(item => {
        item.classList.remove('drag-over');
    });
}

function handleDragOver(event) {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
    
    const target = event.target.closest('.queue-item');
    if (target && !target.classList.contains('dragging')) {
        target.classList.add('drag-over');
    }
}

function handleDragLeave(event) {
    const target = event.target.closest('.queue-item');
    if (target) {
        target.classList.remove('drag-over');
    }
}

async function handleDrop(event, targetIndex) {
    event.preventDefault();
    
    const target = event.target.closest('.queue-item');
    if (target) {
        target.classList.remove('drag-over');
    }
    
    const sourceIndex = queueState.draggedIndex;
    
    if (sourceIndex === -1 || sourceIndex === targetIndex) return;
    
    // 本地重排序以获得即时反馈
    const items = [...queueState.items];
    const [movedItem] = items.splice(sourceIndex, 1);
    items.splice(targetIndex, 0, movedItem);
    queueState.items = items;
    
    renderQueueList();
    
    // 发送重排序请求到服务器
    try {
        const newOrder = items.map(item => item.id);
        await ApiClient.reorderQueue(newOrder);
    } catch (e) {
        console.error('重新排序失败:', e);
        showMessage('重新排序失败: ' + e.message, 'error');
        loadDownloadQueue();
    }
}

// ============================================
// 队列项操作
// ============================================

// 暂停单个项
async function pauseQueueItem(id) {
    try {
        await ApiClient.pauseDownload(id);
        showMessage('已暂停下载', 'success');
        
        const item = queueState.items.find(i => i.id === id);
        if (item) {
            item.status = 'paused';
            renderQueueList();
            updateQueueStats();
        }
    } catch (e) {
        showMessage('暂停失败: ' + e.message, 'error');
    }
}

// 恢复单个项
async function resumeQueueItem(id) {
    try {
        await ApiClient.resumeDownload(id);
        showMessage('已恢复下载', 'success');
        
        const item = queueState.items.find(i => i.id === id);
        if (item) {
            item.status = 'downloading';
            renderQueueList();
            updateQueueStats();
        }
    } catch (e) {
        showMessage('恢复失败: ' + e.message, 'error');
    }
}

// 开始下载队列项
async function startQueueItemDownload(id) {
    try {
        await ApiClient.startDownload(id);
        showMessage('开始下载', 'success');
        
        const item = queueState.items.find(i => i.id === id);
        if (item) {
            item.status = 'downloading';
            renderQueueList();
            updateQueueStats();
        }
    } catch (e) {
        showMessage('开始失败: ' + e.message, 'error');
    }
}

// 暂停所有下载
async function pauseAllDownloads() {
    const activeItems = queueState.items.filter(i => i.status === 'downloading' || i.status === 'pending');
    if (activeItems.length === 0) {
        showMessage('没有正在进行的下载', 'info');
        return;
    }
    
    try {
        for (const item of activeItems) {
            await ApiClient.pauseDownload(item.id);
            item.status = 'paused';
        }
        showMessage(`已暂停 ${activeItems.length} 个下载`, 'success');
        renderQueueList();
        updateQueueStats();
    } catch (e) {
        showMessage('暂停失败: ' + e.message, 'error');
        loadDownloadQueue();
    }
}

// 恢复所有下载
async function resumeAllDownloads() {
    const pausedItems = queueState.items.filter(i => i.status === 'paused');
    if (pausedItems.length === 0) {
        showMessage('没有已暂停的下载', 'info');
        return;
    }
    
    try {
        for (const item of pausedItems) {
            await ApiClient.resumeDownload(item.id);
            item.status = 'pending';
        }
        showMessage(`已恢复 ${pausedItems.length} 个下载`, 'success');
        renderQueueList();
        updateQueueStats();
    } catch (e) {
        showMessage('恢复失败: ' + e.message, 'error');
        loadDownloadQueue();
    }
}

// 清除已完成项
async function clearCompletedQueue() {
    const completedItems = queueState.items.filter(i => i.status === 'completed');
    if (completedItems.length === 0) {
        showMessage('没有已完成的下载', 'info');
        return;
    }
    
    if (!confirm(`确定要清除 ${completedItems.length} 个已完成的下载吗？`)) return;
    
    try {
        for (const item of completedItems) {
            await ApiClient.removeFromQueue(item.id);
        }
        queueState.items = queueState.items.filter(i => i.status !== 'completed');
        showMessage(`已清除 ${completedItems.length} 个已完成的下载`, 'success');
        renderQueueList();
        updateQueueStats();
    } catch (e) {
        showMessage('清除失败: ' + e.message, 'error');
        loadDownloadQueue();
    }
}

// 更新队列项进度（从WebSocket）
function updateQueueItemProgress(progressData) {
    const item = queueState.items.find(i => i.id === progressData.queueId);
    if (item) {
        item.downloadedSize = progressData.downloaded;
        item.totalSize = progressData.total;
        item.speed = progressData.speed;
        item.status = progressData.status;
        
        // 只更新该项，不重新渲染整个列表
        const itemEl = document.querySelector(`.queue-item[data-id="${item.id}"]`);
        if (itemEl) {
            const progress = calculateProgress(item);
            const progressFill = itemEl.querySelector('.queue-progress-fill');
            const progressText = itemEl.querySelectorAll('.queue-progress-text span');
            const speedEl = itemEl.querySelector('[style*="width: 100px"] > div:first-child');
            const etaEl = itemEl.querySelector('[style*="width: 100px"] > div:last-child');
            
            if (progressFill) progressFill.style.width = progress + '%';
            if (progressText[0]) progressText[0].textContent = `${formatBytes(item.downloadedSize || 0)} / ${formatBytes(item.totalSize || 0)}`;
            if (progressText[1]) progressText[1].textContent = progress.toFixed(1) + '%';
            if (speedEl) speedEl.textContent = formatSpeed(item.speed);
            if (etaEl) etaEl.textContent = calculateETA(item);
        }
        
        updateQueueStats();
    }
}
