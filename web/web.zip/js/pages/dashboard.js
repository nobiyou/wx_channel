/**
 * 仪表盘页面模块
 * 从 console.html 提取的仪表盘功能
 * 
 * 注意：此模块会覆盖 console.html 中的同名函数
 * 这是渐进式迁移的一部分
 */

// 仪表盘状态（使用命名空间避免冲突）
const DashboardModule = {
    stats: null,
    chartData: null,
    isLoading: false,
    lastLoadTime: 0,
    minLoadInterval: 10000 // 最小加载间隔：10秒
};

// 初始化仪表盘（保持原函数名以兼容现有调用）
function initDashboardPage() {
    loadDashboardData();
}

// 加载仪表盘数据（覆盖原函数，添加节流）
async function loadDashboardData() {
    // 防止重复加载
    if (DashboardModule.isLoading) return;
    
    // 节流：限制加载频率
    const now = Date.now();
    if (now - DashboardModule.lastLoadTime < DashboardModule.minLoadInterval) {
        console.log('仪表盘数据加载过于频繁，已跳过');
        return;
    }
    
    DashboardModule.isLoading = true;
    DashboardModule.lastLoadTime = now;
    
    try {
        // 加载统计数据 - Requirements: 7.1
        const stats = await ApiClient.getStatistics();
        if (stats.success && stats.data) {
            DashboardModule.stats = stats.data;
            renderDashboardStats(stats.data);
            
            // 渲染最近浏览列表 - Requirements: 7.3
            renderRecentBrowseList(stats.data.recentBrowse || []);
            
            // 渲染最近下载列表 - Requirements: 7.4
            renderRecentDownloadList(stats.data.recentDownload || []);
        }
        
        // 加载图表数据 - Requirements: 7.2
        await loadChartData();
    } catch (e) {
        console.error('加载仪表盘数据失败:', e);
    } finally {
        DashboardModule.isLoading = false;
    }
}

// 渲染统计数据
function renderDashboardStats(data) {
    const elements = {
        'statTotalBrowse': data.totalBrowseCount || 0,
        'statTotalDownload': data.totalDownloadCount || 0,
        'statTodayDownload': data.todayDownloadCount || 0,
        'statStorage': formatBytes(data.storageUsed || 0)
    };
    
    Object.entries(elements).forEach(([id, value]) => {
        const el = document.getElementById(id);
        if (el) {
            el.textContent = typeof value === 'number' ? formatNumber(value) : value;
        }
    });
}

// 加载图表数据 - Requirements: 7.2（覆盖原函数）
async function loadChartData() {
    try {
        const chartData = await ApiClient.getChartData();
        if (chartData.success && chartData.data) {
            DashboardModule.chartData = chartData.data;
            renderChart(chartData.data);
        } else {
            renderEmptyChart();
        }
    } catch (e) {
        console.error('加载图表数据失败:', e);
        renderEmptyChart();
    }
}

// 渲染柱状图 - Requirements: 7.2
function renderChart(data) {
    const container = document.getElementById('chartBars');
    if (!container) return;
    
    if (!data.labels || !data.values || data.labels.length === 0) {
        renderEmptyChart();
        return;
    }
    
    const maxValue = Math.max(...data.values, 1);
    const maxHeight = 140; // pixels
    
    let html = '';
    for (let i = 0; i < data.labels.length; i++) {
        const value = data.values[i] || 0;
        const height = Math.max((value / maxValue) * maxHeight, 4);
        const label = formatChartLabel(data.labels[i]);
        
        html += `
            <div class="chart-bar-wrapper">
                <div class="chart-bar" style="height: ${height}px;" title="${data.labels[i]}: ${value} 次下载">
                    ${value > 0 ? `<span class="chart-bar-value">${value}</span>` : ''}
                </div>
                <span class="chart-label">${label}</span>
            </div>
        `;
    }
    
    container.innerHTML = html;
}

// 渲染空图表状态
function renderEmptyChart() {
    const container = document.getElementById('chartBars');
    if (container) {
        container.innerHTML = '<div class="chart-empty">暂无下载数据</div>';
    }
}

// 格式化图表标签（日期转短格式）
function formatChartLabel(dateStr) {
    try {
        const date = new Date(dateStr);
        return `${date.getMonth() + 1}/${date.getDate()}`;
    } catch (e) {
        return dateStr;
    }
}

// 渲染最近浏览列表 - Requirements: 7.3
function renderRecentBrowseList(records) {
    const container = document.getElementById('recentBrowseList');
    if (!container) return;
    
    if (!records || records.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                    <circle cx="12" cy="12" r="3"/>
                </svg>
                <p>暂无浏览记录</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    for (const record of records) {
        const thumbnail = record.coverUrl 
            ? `<img class="recent-thumbnail" src="${escapeHtml(record.coverUrl)}" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"><div class="recent-thumbnail-placeholder" style="display:none"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg></div>`
            : `<div class="recent-thumbnail-placeholder"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg></div>`;
        
        const duration = record.duration ? formatDuration(record.duration) : '';
        const author = record.author || '未知作者';
        const browseTime = record.browseTime ? formatRelativeTime(record.browseTime) : '';
        const title = record.title || '无标题';
        
        html += `
            <div class="recent-item" onclick="viewBrowseRecord('${escapeHtml(record.id)}')">
                ${thumbnail}
                <div class="recent-info">
                    <div class="recent-title" title="${escapeHtml(title)}">${escapeHtml(title)}</div>
                    <div class="recent-meta">
                        <span>${escapeHtml(author)}</span>
                        ${duration ? `<span>${duration}</span>` : ''}
                        ${browseTime ? `<span>${browseTime}</span>` : ''}
                    </div>
                </div>
            </div>
        `;
    }
    
    container.innerHTML = html;
}

// 渲染最近下载列表 - Requirements: 7.4
function renderRecentDownloadList(records) {
    const container = document.getElementById('recentDownloadList');
    if (!container) return;
    
    if (!records || records.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
                </svg>
                <p>暂无下载记录</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    for (const record of records) {
        const statusClass = record.status || 'completed';
        const statusText = getDashboardStatusText(record.status);
        const author = record.author || '未知作者';
        const fileSize = record.fileSize ? formatBytes(record.fileSize) : '';
        const downloadTime = record.downloadTime ? formatRelativeTime(record.downloadTime) : '';
        const title = record.title || '无标题';
        
        // 显示封面图，如果没有则显示占位符
        const thumbnail = record.coverUrl 
            ? `<img class="recent-thumbnail" src="${escapeHtml(record.coverUrl)}" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"><div class="recent-thumbnail-placeholder" style="display:none"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg></div>`
            : `<div class="recent-thumbnail-placeholder"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg></div>`;
        
        html += `
            <div class="recent-item" onclick="viewDownloadRecord('${escapeHtml(record.id)}')">
                ${thumbnail}
                <div class="recent-info">
                    <div class="recent-title" title="${escapeHtml(title)}">${escapeHtml(title)}</div>
                    <div class="recent-meta">
                        <span>${escapeHtml(author)}</span>
                        ${fileSize ? `<span>${fileSize}</span>` : ''}
                        ${downloadTime ? `<span>${downloadTime}</span>` : ''}
                    </div>
                </div>
                <span class="recent-status ${statusClass}">${statusText}</span>
            </div>
        `;
    }
    
    container.innerHTML = html;
}

// 获取状态显示文本（仪表盘专用，避免与其他模块冲突）
function getDashboardStatusText(status) {
    const statusMap = {
        'completed': '已完成',
        'failed': '失败',
        'in_progress': '下载中',
        'pending': '等待中',
        'paused': '已暂停'
    };
    return statusMap[status] || status || '未知';
}

// 查看浏览记录详情
function viewBrowseRecord(id) {
    navigateTo('browse');
    // 可以在这里添加显示特定记录详情的逻辑
}

// 查看下载记录详情
function viewDownloadRecord(id) {
    navigateTo('downloads');
    // 可以在这里添加显示特定记录详情的逻辑
}

// 刷新仪表盘
function refreshDashboard() {
    loadDashboardData();
}

// 导出模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        initDashboardPage,
        loadDashboardData,
        refreshDashboard
    };
}
