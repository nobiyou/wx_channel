/**
 * 设置页面模块
 */

const SettingsState = {
    config: {},
    isLoading: false,
    isSaving: false
};

// 初始化设置页面
function initSettingsPage() {
    loadSettings();
}

// 加载设置
async function loadSettings() {
    try {
        SettingsState.isLoading = true;
        showSettingsLoading();
        
        const config = await API.getConfig();
        SettingsState.config = config || {};
        
        renderSettings();
        
    } catch (error) {
        console.error('加载设置失败:', error);
        showSettingsError('加载失败: ' + error.message);
    } finally {
        SettingsState.isLoading = false;
    }
}

// 渲染设置
function renderSettings() {
    const container = document.getElementById('settings-content');
    if (!container) return;
    
    const config = SettingsState.config;
    
    container.innerHTML = `
        <div class="settings-container">
            <div class="settings-section">
                <h3 class="settings-section-title">下载设置</h3>
                <div class="settings-group">
                    <div class="form-group">
                        <label class="form-label">下载目录</label>
                        <div class="input-group">
                            <input type="text" id="download-path" class="form-input" 
                                   value="${escapeHtml(config.download_path || config.downloadPath || '')}" 
                                   placeholder="选择下载目录">
                            <button class="btn btn-secondary" onclick="selectDownloadPath()">浏览</button>
                        </div>
                        <p class="form-help">视频文件将保存到此目录</p>
                    </div>

                    <div class="form-group">
                        <label class="form-label">并发下载数</label>
                        <input type="number" id="concurrent-downloads" class="form-input" 
                               value="${config.concurrent_downloads || config.concurrentDownloads || 3}" 
                               min="1" max="10">
                        <p class="form-help">同时下载的视频数量 (1-10)</p>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">
                            <input type="checkbox" id="auto-download" ${config.auto_download || config.autoDownload ? 'checked' : ''}>
                            自动下载浏览的视频
                        </label>
                        <p class="form-help">浏览视频时自动添加到下载队列</p>
                    </div>
                </div>
            </div>
            
            <div class="settings-section">
                <h3 class="settings-section-title">代理设置</h3>
                <div class="settings-group">
                    <div class="form-group">
                        <label class="form-label">代理端口</label>
                        <input type="number" id="proxy-port" class="form-input" 
                               value="${config.proxy_port || config.proxyPort || 9527}" 
                               min="1024" max="65535">
                        <p class="form-help">本地代理服务端口</p>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Web控制台端口</label>
                        <input type="number" id="web-port" class="form-input" 
                               value="${config.web_port || config.webPort || 9528}" 
                               min="1024" max="65535">
                        <p class="form-help">Web控制台访问端口</p>
                    </div>
                </div>
            </div>
            
            <div class="settings-section">
                <h3 class="settings-section-title">文件命名</h3>
                <div class="settings-group">
                    <div class="form-group">
                        <label class="form-label">文件名模板</label>
                        <input type="text" id="filename-template" class="form-input" 
                               value="${escapeHtml(config.filename_template || config.filenameTemplate || '{title}')}" 
                               placeholder="{title}">
                        <p class="form-help">可用变量: {title}, {author}, {date}, {id}</p>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">
                            <input type="checkbox" id="create-author-folder" ${config.create_author_folder || config.createAuthorFolder ? 'checked' : ''}>
                            按作者创建子文件夹
                        </label>
                    </div>
                </div>
            </div>
            
            <div class="settings-actions">
                <button class="btn btn-primary" onclick="saveSettings()" ${SettingsState.isSaving ? 'disabled' : ''}>
                    ${SettingsState.isSaving ? '保存中...' : '保存设置'}
                </button>
                <button class="btn btn-secondary" onclick="loadSettings()">重置</button>
            </div>
        </div>
    `;
}

function showSettingsLoading() {
    const container = document.getElementById('settings-content');
    if (container) {
        container.innerHTML = '<div class="loading-state"><div class="loading-spinner"></div><p>加载中...</p></div>';
    }
}

function showSettingsError(message) {
    const container = document.getElementById('settings-content');
    if (container) {
        container.innerHTML = `<div class="empty-state"><h3>加载失败</h3><p>${escapeHtml(message)}</p><button class="btn btn-primary" onclick="loadSettings()">重试</button></div>`;
    }
}

// 保存设置
async function saveSettings() {
    try {
        SettingsState.isSaving = true;
        
        const config = {
            download_path: document.getElementById('download-path')?.value || '',
            concurrent_downloads: parseInt(document.getElementById('concurrent-downloads')?.value) || 3,
            auto_download: document.getElementById('auto-download')?.checked || false,
            proxy_port: parseInt(document.getElementById('proxy-port')?.value) || 9527,
            web_port: parseInt(document.getElementById('web-port')?.value) || 9528,
            filename_template: document.getElementById('filename-template')?.value || '{title}',
            create_author_folder: document.getElementById('create-author-folder')?.checked || false
        };
        
        await API.saveConfig(config);
        SettingsState.config = config;
        Toast.success('设置已保存');
        
    } catch (error) {
        Toast.error('保存失败: ' + error.message);
    } finally {
        SettingsState.isSaving = false;
        renderSettings();
    }
}

// 选择下载目录
async function selectDownloadPath() {
    try {
        const path = await API.selectFolder();
        if (path) {
            document.getElementById('download-path').value = path;
        }
    } catch (error) {
        Toast.error('选择目录失败: ' + error.message);
    }
}
