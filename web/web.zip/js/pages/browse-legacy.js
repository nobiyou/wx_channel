/**
 * 浏览记录页面模块（兼容原 console.html）
 * 从 console.html 提取并模块化
 */

// 浏览记录状态
var browseState = {
    records: [],
    currentPage: 1,
    pageSize: 20,
    totalCount: 0,
    totalPages: 0,
    searchQuery: '',
    selectedIds: new Set(),
    currentDetailId: null
};

var browseSearchDebounceTimer = null;

console.log('浏览记录模块：使用模块化版本');

// 加载浏览记录（覆盖原函数）
async function loadBrowseHistory() {
    if (typeof ConnectionManager !== 'undefined' && ConnectionManager.getStatus() !== 'connected') {
        renderBrowseEmptyState('请先连接到本地服务');
        return;
    }

    try {
        const params = {
            page: browseState.currentPage,
            pageSize: browseState.pageSize
        };
        
        if (browseState.searchQuery) {
            params.search = browseState.searchQuery;
        }

        const response = await ApiClient.getBrowseHistory(params);
        
        if (response.success && response.data) {
            browseState.records = response.data.items || [];
            browseState.totalCount = response.data.total || 0;
            browseState.totalPages = response.data.totalPages || 0;
            
            renderBrowseHistory();
            renderBrowsePagination();
        } else {
            renderBrowseEmptyState(response.error || '加载失败');
        }
    } catch (e) {
        console.error('加载浏览记录失败:', e);
        renderBrowseEmptyState('加载失败: ' + e.message);
    }
}

// 渲染浏览记录列表
function renderBrowseHistory() {
    const container = document.getElementById('browseHistoryList');
    if (!container) return;
    
    if (browseState.records.length === 0) {
        renderBrowseEmptyState(browseState.searchQuery ? '未找到匹配的记录' : '暂无浏览记录');
        return;
    }
    
    let html = '<div class="card"><table class="data-table"><thead><tr>';
    html += '<th width="40"><input type="checkbox" id="browseSelectAll" onchange="toggleBrowseSelectAll(this.checked)"></th>';
    html += '<th width="80">封面</th>';
    html += '<th>标题</th>';
    html += '<th width="120">作者</th>';
    html += '<th width="80">时长</th>';
    html += '<th width="120">浏览时间</th>';
    html += '<th width="120">操作</th>';
    html += '</tr></thead><tbody>';
    
    for (const record of browseState.records) {
        const isSelected = browseState.selectedIds.has(record.id);
        const thumbnail = record.coverUrl 
            ? `<img class="table-thumbnail" src="${escapeHtml(record.coverUrl)}" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'"><div class="table-thumbnail-placeholder" style="display:none"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg></div>`
            : `<div class="table-thumbnail-placeholder"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg></div>`;
        
        html += `<tr class="${isSelected ? 'selected' : ''}" onclick="if(event.target.type !== 'checkbox' && event.target.tagName !== 'BUTTON') viewBrowseRecord('${escapeHtml(record.id)}')">`;
        html += `<td><input type="checkbox" ${isSelected ? 'checked' : ''} onchange="toggleBrowseSelect('${escapeHtml(record.id)}')" onclick="event.stopPropagation()"></td>`;
        html += `<td>${thumbnail}</td>`;
        html += `<td><div class="table-title">${escapeHtml(record.title || '无标题')}</div></td>`;
        html += `<td><span class="table-author">${escapeHtml(record.author || '未知作者')}</span></td>`;
        html += `<td><span class="table-meta">${record.duration ? formatDuration(record.duration) : '-'}</span></td>`;
        html += `<td><span class="table-meta">${formatRelativeTime(record.browseTime)}</span></td>`;
        html += `<td onclick="event.stopPropagation()"><div class="table-actions">`;
        html += `<button class="table-action-btn" onclick="addBrowseToDownloadQueue('${escapeHtml(record.id)}')" title="添加到下载队列"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></button>`;
        html += `<button class="table-action-btn" onclick="deleteBrowseRecord('${escapeHtml(record.id)}')" title="删除"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button>`;
        html += `</div></td>`;
        html += '</tr>';
    }
    
    html += '</tbody></table></div>';
    container.innerHTML = html;
    
    // 更新批量操作栏
    updateBrowseBatchActions();
}

// 渲染分页
function renderBrowsePagination() {
    const container = document.getElementById('browsePagination');
    if (!container) return;
    
    if (browseState.totalPages <= 1) {
        container.innerHTML = '';
        return;
    }
    
    let html = '<div class="pagination">';
    html += `<button ${browseState.currentPage <= 1 ? 'disabled' : ''} onclick="browsePage(${browseState.currentPage - 1})">上一页</button>`;
    
    // 显示页码
    const startPage = Math.max(1, browseState.currentPage - 2);
    const endPage = Math.min(browseState.totalPages, browseState.currentPage + 2);
    
    if (startPage > 1) {
        html += `<button onclick="browsePage(1)">1</button>`;
        if (startPage > 2) html += '<span>...</span>';
    }
    
    for (let i = startPage; i <= endPage; i++) {
        html += `<button class="${i === browseState.currentPage ? 'active' : ''}" onclick="browsePage(${i})">${i}</button>`;
    }
    
    if (endPage < browseState.totalPages) {
        if (endPage < browseState.totalPages - 1) html += '<span>...</span>';
        html += `<button onclick="browsePage(${browseState.totalPages})">${browseState.totalPages}</button>`;
    }
    
    html += `<button ${browseState.currentPage >= browseState.totalPages ? 'disabled' : ''} onclick="browsePage(${browseState.currentPage + 1})">下一页</button>`;
    html += `<span class="pagination-info">共 ${browseState.totalCount} 条记录</span>`;
    html += '</div>';
    
    container.innerHTML = html;
}

// 渲染空状态
function renderBrowseEmptyState(message) {
    const container = document.getElementById('browseHistoryList');
    if (!container) return;
    
    container.innerHTML = `
        <div class="table-empty-state">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                <circle cx="12" cy="12" r="3"/>
            </svg>
            <p>${escapeHtml(message)}</p>
        </div>
    `;
}

// 切换页码
function browsePage(page) {
    if (page < 1 || page > browseState.totalPages) return;
    browseState.currentPage = page;
    loadBrowseHistory();
}

// 搜索浏览记录
function searchBrowseHistory(query) {
    clearTimeout(browseSearchDebounceTimer);
    browseSearchDebounceTimer = setTimeout(() => {
        browseState.searchQuery = query;
        browseState.currentPage = 1;
        loadBrowseHistory();
    }, 300);
}

// 切换选择
function toggleBrowseSelect(id) {
    if (browseState.selectedIds.has(id)) {
        browseState.selectedIds.delete(id);
    } else {
        browseState.selectedIds.add(id);
    }
    renderBrowseHistory();
}

// 全选/取消全选
function toggleBrowseSelectAll(checked) {
    if (checked) {
        browseState.records.forEach(r => browseState.selectedIds.add(r.id));
    } else {
        browseState.selectedIds.clear();
    }
    renderBrowseHistory();
}

// 更新批量操作栏
function updateBrowseBatchActions() {
    const batchBar = document.getElementById('browseBatchActionsBar');
    const selectedCount = document.getElementById('browseSelectedCount');
    
    if (batchBar) {
        batchBar.style.display = browseState.selectedIds.size > 0 ? 'flex' : 'none';
    }
    
    if (selectedCount) {
        selectedCount.textContent = browseState.selectedIds.size;
    }
}

// 查看记录详情
function viewBrowseRecord(id) {
    browseState.currentDetailId = id;
    const record = browseState.records.find(r => r.id === id);
    if (!record) return;
    
    // 显示详情面板（如果有的话）
    console.log('查看浏览记录详情:', record);
    // TODO: 实现详情面板
}

// 添加到下载队列
async function addBrowseToDownloadQueue(id) {
    try {
        const response = await ApiClient.addToDownloadQueue([id]);
        if (response.success) {
            if (typeof showMessage === 'function') {
                showMessage('已添加到下载队列', 'success');
            }
        } else {
            if (typeof showMessage === 'function') {
                showMessage(response.error || '添加失败', 'error');
            }
        }
    } catch (e) {
        console.error('添加到下载队列失败:', e);
        if (typeof showMessage === 'function') {
            showMessage('添加失败: ' + e.message, 'error');
        }
    }
}

// 批量添加到下载队列
async function addSelectedBrowseToQueue() {
    if (browseState.selectedIds.size === 0) return;
    
    try {
        const ids = Array.from(browseState.selectedIds);
        const response = await ApiClient.addToDownloadQueue(ids);
        if (response.success) {
            if (typeof showMessage === 'function') {
                showMessage(`已添加 ${ids.length} 个视频到下载队列`, 'success');
            }
            browseState.selectedIds.clear();
            renderBrowseHistory();
        } else {
            if (typeof showMessage === 'function') {
                showMessage(response.error || '批量添加失败', 'error');
            }
        }
    } catch (e) {
        console.error('批量添加到下载队列失败:', e);
        if (typeof showMessage === 'function') {
            showMessage('批量添加失败: ' + e.message, 'error');
        }
    }
}

// 删除记录
async function deleteBrowseRecord(id) {
    if (!confirm('确定要删除这条浏览记录吗？')) return;
    
    try {
        const response = await ApiClient.deleteBrowseRecord(id);
        if (response.success) {
            if (typeof showMessage === 'function') {
                showMessage('删除成功', 'success');
            }
            loadBrowseHistory();
        } else {
            if (typeof showMessage === 'function') {
                showMessage(response.error || '删除失败', 'error');
            }
        }
    } catch (e) {
        console.error('删除浏览记录失败:', e);
        if (typeof showMessage === 'function') {
            showMessage('删除失败: ' + e.message, 'error');
        }
    }
}

// 批量删除
async function deleteSelectedBrowseRecords() {
    if (browseState.selectedIds.size === 0) return;
    if (!confirm(`确定要删除选中的 ${browseState.selectedIds.size} 条记录吗？`)) return;
    
    try {
        const ids = Array.from(browseState.selectedIds);
        const response = await ApiClient.deleteBrowseRecords(ids);
        if (response.success) {
            if (typeof showMessage === 'function') {
                showMessage('批量删除成功', 'success');
            }
            browseState.selectedIds.clear();
            loadBrowseHistory();
        } else {
            if (typeof showMessage === 'function') {
                showMessage(response.error || '批量删除失败', 'error');
            }
        }
    } catch (e) {
        console.error('批量删除浏览记录失败:', e);
        if (typeof showMessage === 'function') {
            showMessage('批量删除失败: ' + e.message, 'error');
        }
    }
}

// 导出模块
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        loadBrowseHistory,
        searchBrowseHistory,
        browsePage,
        browseState
    };
}

console.log('浏览记录模块已加载（模块化版本）');
