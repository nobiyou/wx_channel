/**
 * 采集队列页面模块
 */

const QueueState = {
    items: [],
    currentPage: 1,
    pageSize: 20,
    totalCount: 0,
    statusFilter: '',
    isProcessing: false
};

// 初始化队列页面
function initQueuePage() {
    loadQueueItems(1);
}

// 加载队列项目
async function loadQueueItems(page = 1) {
    try {
        showQueueLoading();
        
        const params = {
            page,
            limit: QueueState.pageSize,
            status: QueueState.statusFilter
        };
        
        const response = await API.getQueueItems(params);
        
        QueueState.items = response.items || [];
        QueueState.currentPage = page;
        QueueState.totalCount = response.total || 0;
        QueueState.isProcessing = response.is_processing || false;
        
        renderQueueItems();
        
    } catch (error) {
        console.error('加载队列失败:', error);
        showQueueError('加载失败: ' + error.message);
    }
}

// 渲染队列项目
function renderQueueItems() {
    const container = document.getElementById('queue-content');
    if (!container) return;
    
    if (QueueState.items.length === 0 && !QueueState.statusFilter) {
        container.innerHTML = renderQueueEmpty();
        return;
    }

    const totalPages = Math.ceil(QueueState.totalCount / QueueState.pageSize);
    
    container.innerHTML = `
        <div class="table-container">
            <div class="table-toolbar">
                <div class="table-toolbar-left">
                    <select id="queue-status-filter" class="form-select">
                        <option value="">全部状态</option>
                        <option value="pending" ${QueueState.statusFilter === 'pending' ? 'selected' : ''}>等待中</option>
                        <option value="downloading" ${QueueState.statusFilter === 'downloading' ? 'selected' : ''}>下载中</option>
                        <option value="completed" ${QueueState.statusFilter === 'completed' ? 'selected' : ''}>已完成</option>
                        <option value="failed" ${QueueState.statusFilter === 'failed' ? 'selected' : ''}>失败</option>
                    </select>
                    <span class="queue-status-indicator ${QueueState.isProcessing ? 'processing' : ''}">
                        ${QueueState.isProcessing ? '⏳ 处理中...' : '⏸ 已暂停'}
                    </span>
                </div>
                <div class="table-toolbar-right">
                    <button class="btn ${QueueState.isProcessing ? 'btn-warning' : 'btn-primary'}" onclick="toggleQueueProcessing()">
                        ${QueueState.isProcessing ? '暂停队列' : '开始处理'}
                    </button>
                    <button class="btn btn-secondary" onclick="clearCompletedQueue()">清除已完成</button>
                    <button class="btn btn-secondary" onclick="loadQueueItems(1)">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:16px;height:16px">
                            <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
                            <path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"/>
                        </svg>
                        刷新
                    </button>
                </div>
            </div>
            
            <table class="table">
                <thead>
                    <tr>
                        <th width="80">封面</th>
                        <th>标题</th>
                        <th width="100">状态</th>
                        <th width="120">进度</th>
                        <th width="140">添加时间</th>
                        <th width="100">操作</th>
                    </tr>
                </thead>
                <tbody>
                    ${QueueState.items.length > 0 
                        ? QueueState.items.map(item => renderQueueRow(item)).join('')
                        : '<tr><td colspan="6" class="table-empty">没有找到匹配的项目</td></tr>'
                    }
                </tbody>
            </table>
            
            ${totalPages > 1 ? `
            <div class="pagination">
                <div class="pagination-info">共 ${QueueState.totalCount} 条，第 ${QueueState.currentPage}/${totalPages} 页</div>
                <div class="pagination-controls">
                    <button class="pagination-btn" ${QueueState.currentPage <= 1 ? 'disabled' : ''} onclick="loadQueueItems(${QueueState.currentPage - 1})">上一页</button>
                    <span class="pagination-current">${QueueState.currentPage}</span>
                    <button class="pagination-btn" ${QueueState.currentPage >= totalPages ? 'disabled' : ''} onclick="loadQueueItems(${QueueState.currentPage + 1})">下一页</button>
                </div>
            </div>
            ` : ''}
        </div>
    `;
    
    // 绑定筛选事件
    document.getElementById('queue-status-filter')?.addEventListener('change', (e) => {
        QueueState.statusFilter = e.target.value;
        loadQueueItems(1);
    });
}

// 渲染队列行
function renderQueueRow(item) {
    const coverUrl = item.cover_url || item.coverUrl || '';
    const status = item.status || 'pending';
    const statusMap = {
        pending: { text: '等待中', class: 'secondary' },
        downloading: { text: '下载中', class: 'warning' },
        completed: { text: '已完成', class: 'success' },
        failed: { text: '失败', class: 'danger' }
    };
    const statusInfo = statusMap[status] || statusMap.pending;
    const progress = item.progress || 0;
    
    return `
        <tr data-id="${item.id}">
            <td>
                ${coverUrl 
                    ? `<img src="${coverUrl}" class="table-thumbnail" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 60 40%22><rect fill=%22%23f0f0f0%22 width=%2260%22 height=%2240%22/></svg>'">`
                    : '<div class="table-thumbnail-placeholder"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg></div>'
                }
            </td>
            <td>
                <div class="table-title" title="${escapeHtml(item.title || '')}">${escapeHtml(item.title || '无标题')}</div>
                <div class="table-author">${escapeHtml(item.author || item.nickname || '')}</div>
            </td>
            <td><span class="status-badge status-${statusInfo.class}">${statusInfo.text}</span></td>
            <td>
                ${status === 'downloading' ? `
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${progress}%"></div>
                </div>
                <span class="progress-text">${progress}%</span>
                ` : '-'}
            </td>
            <td><span class="table-meta">${formatRelativeTime(item.created_at || item.createdAt)}</span></td>
            <td>
                <div class="table-actions">
                    ${status === 'failed' ? `
                    <button class="btn btn-sm btn-primary" onclick="retryQueueItem('${item.id}')" title="重试">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px">
                            <polyline points="23 4 23 10 17 10"/><path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10"/>
                        </svg>
                    </button>
                    ` : ''}
                    <button class="btn btn-sm btn-danger" onclick="removeQueueItem('${item.id}')" title="移除">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px">
                            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
                        </svg>
                    </button>
                </div>
            </td>
        </tr>
    `;
}


function showQueueLoading() {
    const container = document.getElementById('queue-content');
    if (container) {
        container.innerHTML = '<div class="loading-state"><div class="loading-spinner"></div><p>加载中...</p></div>';
    }
}

function showQueueError(message) {
    const container = document.getElementById('queue-content');
    if (container) {
        container.innerHTML = `<div class="empty-state"><h3>加载失败</h3><p>${escapeHtml(message)}</p><button class="btn btn-primary" onclick="loadQueueItems(1)">重试</button></div>`;
    }
}

function renderQueueEmpty() {
    return `
        <div class="empty-state">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/>
                <line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>
            </svg>
            <h3>队列为空</h3>
            <p>从浏览记录添加视频到队列开始下载</p>
        </div>
    `;
}

// 操作函数
async function toggleQueueProcessing() {
    try {
        if (QueueState.isProcessing) {
            await API.pauseQueue();
            Toast.success('队列已暂停');
        } else {
            await API.startQueue();
            Toast.success('队列开始处理');
        }
        loadQueueItems(QueueState.currentPage);
    } catch (error) {
        Toast.error('操作失败: ' + error.message);
    }
}

async function retryQueueItem(id) {
    try {
        await API.retryQueueItem(id);
        Toast.success('已重新加入队列');
        loadQueueItems(QueueState.currentPage);
    } catch (error) {
        Toast.error('重试失败: ' + error.message);
    }
}

async function removeQueueItem(id) {
    const confirmed = await Modal.confirm({
        title: '确认移除',
        message: '确定要从队列中移除这个项目吗？',
        type: 'danger'
    });
    
    if (confirmed) {
        try {
            await API.removeQueueItem(id);
            Toast.success('已移除');
            loadQueueItems(QueueState.currentPage);
        } catch (error) {
            Toast.error('移除失败: ' + error.message);
        }
    }
}

async function clearCompletedQueue() {
    const confirmed = await Modal.confirm({
        title: '清除已完成',
        message: '确定要清除所有已完成的队列项目吗？',
        type: 'warning'
    });
    
    if (confirmed) {
        try {
            await API.clearCompletedQueue();
            Toast.success('已清除完成项目');
            loadQueueItems(1);
        } catch (error) {
            Toast.error('清除失败: ' + error.message);
        }
    }
}
