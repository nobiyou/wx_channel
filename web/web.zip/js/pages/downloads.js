/**
 * 下载记录页面模块
 */

const DownloadState = {
    records: [],
    currentPage: 1,
    pageSize: 20,
    totalCount: 0,
    searchKeyword: '',
    statusFilter: ''
};

// 初始化下载记录页面
function initDownloadsPage() {
    loadDownloadRecords(1);
}

// 加载下载记录
async function loadDownloadRecords(page = 1) {
    try {
        showDownloadLoading();
        
        const params = {
            page,
            limit: DownloadState.pageSize,
            search: DownloadState.searchKeyword,
            status: DownloadState.statusFilter
        };
        
        const response = await API.getDownloadRecords(params);
        
        DownloadState.records = response.records || [];
        DownloadState.currentPage = page;
        DownloadState.totalCount = response.total || 0;
        
        renderDownloadRecords();
        
    } catch (error) {
        console.error('加载下载记录失败:', error);
        showDownloadError('加载失败: ' + error.message);
    }
}

// 渲染下载记录
function renderDownloadRecords() {
    const container = document.getElementById('downloads-content');
    if (!container) return;
    
    if (DownloadState.records.length === 0 && !DownloadState.searchKeyword && !DownloadState.statusFilter) {
        container.innerHTML = renderDownloadEmpty();
        return;
    }
    
    const totalPages = Math.ceil(DownloadState.totalCount / DownloadState.pageSize);
    
    container.innerHTML = `
        <div class="table-container">
            <div class="table-toolbar">
                <div class="table-toolbar-left">
                    <div class="table-search">
                        <svg class="table-search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
                        </svg>
                        <input type="search" id="download-search" placeholder="搜索标题..." value="${escapeHtml(DownloadState.searchKeyword)}">
                    </div>
                    <select id="download-status-filter" class="form-select">
                        <option value="">全部状态</option>
                        <option value="completed" ${DownloadState.statusFilter === 'completed' ? 'selected' : ''}>已完成</option>
                        <option value="failed" ${DownloadState.statusFilter === 'failed' ? 'selected' : ''}>失败</option>
                    </select>
                </div>
                <div class="table-toolbar-right">
                    <button class="btn btn-secondary" onclick="openDownloadFolder()" title="打开下载文件夹">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:16px;height:16px">
                            <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
                        </svg>
                        打开文件夹
                    </button>
                    <button class="btn btn-secondary" onclick="loadDownloadRecords(1)">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:16px;height:16px">
                            <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
                            <path d="M20.49 9A9 9 0 0 0 5.64 5.64L1 10m22 4l-4.64 4.36A9 9 0 0 1 3.51 15"/>
                        </svg>
                        刷新
                    </button>
                </div>
            </div>
            
            <table class="table">
                <thead>
                    <tr>
                        <th width="80">封面</th>
                        <th>标题</th>
                        <th width="100">文件大小</th>
                        <th width="100">状态</th>
                        <th width="140">下载时间</th>
                        <th width="100">操作</th>
                    </tr>
                </thead>
                <tbody>
                    ${DownloadState.records.length > 0 
                        ? DownloadState.records.map(record => renderDownloadRow(record)).join('')
                        : '<tr><td colspan="6" class="table-empty">没有找到匹配的记录</td></tr>'
                    }
                </tbody>
            </table>
            
            ${totalPages > 1 ? `
            <div class="pagination">
                <div class="pagination-info">共 ${DownloadState.totalCount} 条，第 ${DownloadState.currentPage}/${totalPages} 页</div>
                <div class="pagination-controls">
                    <button class="pagination-btn" ${DownloadState.currentPage <= 1 ? 'disabled' : ''} onclick="loadDownloadRecords(${DownloadState.currentPage - 1})">上一页</button>
                    <span class="pagination-current">${DownloadState.currentPage}</span>
                    <button class="pagination-btn" ${DownloadState.currentPage >= totalPages ? 'disabled' : ''} onclick="loadDownloadRecords(${DownloadState.currentPage + 1})">下一页</button>
                </div>
            </div>
            ` : ''}
        </div>
    `;
    
    // 绑定事件
    document.getElementById('download-search')?.addEventListener('input', debounce((e) => {
        DownloadState.searchKeyword = e.target.value;
        loadDownloadRecords(1);
    }, 300));
    
    document.getElementById('download-status-filter')?.addEventListener('change', (e) => {
        DownloadState.statusFilter = e.target.value;
        loadDownloadRecords(1);
    });
}

// 渲染下载记录行
function renderDownloadRow(record) {
    const coverUrl = record.cover_url || record.coverUrl || '';
    const status = record.status || 'completed';
    const statusText = { completed: '已完成', failed: '失败', downloading: '下载中' }[status] || status;
    const statusClass = { completed: 'success', failed: 'danger', downloading: 'warning' }[status] || '';
    
    return `
        <tr>
            <td>
                ${coverUrl 
                    ? `<img src="${coverUrl}" class="table-thumbnail" onclick="openLightbox('${escapeHtml(coverUrl)}', '${escapeHtml(record.title || '')}')" onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 60 40%22><rect fill=%22%23f0f0f0%22 width=%2260%22 height=%2240%22/></svg>'">`
                    : '<div class="table-thumbnail-placeholder"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg></div>'
                }
            </td>
            <td>
                <div class="table-title" title="${escapeHtml(record.title || '')}">${escapeHtml(record.title || '无标题')}</div>
                <div class="table-author">${escapeHtml(record.author || record.nickname || '')}</div>
            </td>
            <td><span class="table-meta">${record.file_size ? formatFileSize(record.file_size) : '-'}</span></td>
            <td><span class="status-badge status-${statusClass}">${statusText}</span></td>
            <td><span class="table-meta">${formatRelativeTime(record.download_time || record.downloadTime)}</span></td>
            <td>
                <div class="table-actions">
                    ${status === 'completed' ? `
                    <button class="btn btn-sm btn-secondary" onclick="openDownloadFile('${record.id}')" title="打开文件">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px">
                            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
                            <polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
                        </svg>
                    </button>
                    ` : ''}
                    <button class="btn btn-sm btn-danger" onclick="deleteDownloadRecord('${record.id}')" title="删除记录">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:14px;height:14px">
                            <polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
                        </svg>
                    </button>
                </div>
            </td>
        </tr>
    `;
}

function showDownloadLoading() {
    const container = document.getElementById('downloads-content');
    if (container) {
        container.innerHTML = '<div class="loading-state"><div class="loading-spinner"></div><p>加载中...</p></div>';
    }
}

function showDownloadError(message) {
    const container = document.getElementById('downloads-content');
    if (container) {
        container.innerHTML = `<div class="empty-state"><h3>加载失败</h3><p>${escapeHtml(message)}</p><button class="btn btn-primary" onclick="loadDownloadRecords(1)">重试</button></div>`;
    }
}

function renderDownloadEmpty() {
    return `
        <div class="empty-state">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            <h3>暂无下载记录</h3>
            <p>下载视频后，记录会显示在这里</p>
        </div>
    `;
}

// 操作函数
async function openDownloadFolder() {
    try {
        await API.openDownloadFolder();
    } catch (error) {
        Toast.error('打开文件夹失败: ' + error.message);
    }
}

async function openDownloadFile(id) {
    try {
        await API.openDownloadFile(id);
    } catch (error) {
        Toast.error('打开文件失败: ' + error.message);
    }
}

async function deleteDownloadRecord(id) {
    const confirmed = await Modal.confirm({
        title: '确认删除',
        message: '确定要删除这条下载记录吗？（不会删除已下载的文件）',
        type: 'danger'
    });
    
    if (confirmed) {
        try {
            await API.deleteDownloadRecord(id);
            Toast.success('删除成功');
            loadDownloadRecords(DownloadState.currentPage);
        } catch (error) {
            Toast.error('删除失败: ' + error.message);
        }
    }
}
